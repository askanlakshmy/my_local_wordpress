<?php
//define('WP_USE_THEMES', true);
include 'simplexlsx.class.php';
//include '../sound-effects/wp-load.php';
//add_action('wp', 'insert_custom_products', 10);
add_action('wp_ajax_rkb_perform_import_soundeffects', 'rkb_insert_custom_products', 10);

//WC()->api->includes();
//WC()->api->register_resources(new WC_API_Server( '/' ));
/*
It is an useful query
INSERT INTO `wp_postmeta`(post_id, meta_key, meta_value) 
SELECT p.ID, '_visibility', 'visible' FROM 
(SELECT ID FROM wp_posts WHERE post_type="product" ORDER BY `ID` DESC) p;
*/

function rkb_insert_custom_products(){
    global $wpdb, $RkbBlastDriveImport;    
    
    //die('Comment the line '.__LINE__.' to start again');
    set_time_limit(0);
    $benchmark = microtime(true);
	if(!isset($_POST['_wp_nonce']) || !wp_verify_nonce( $_POST['_wp_nonce'], 'rkb7743v45f' )){
		//die('Access Denied.');
		echo '-1';
		die();
	}
	
	$importfile = stripslashes(str_replace('../', '', $_POST['rkb_import_file']));
	$dirpath = $RkbBlastDriveImport->plugin_dir.'/upload';
	
	if(!file_exists($dirpath.'/'.$importfile)){
		//die($importfile.' doesn\'t found.');
		echo '-2';
		die();
	}
	
    $xlsx = new SimpleXLSX($dirpath.'/'.$importfile);
    $data = $xlsx->worksheet(1);
    $rows = $data->sheetData->row;
    $simple = get_term_by('slug','simple','product_type');
    $productsql = $productmetasql = $productcatsql = $taxcountssql = '';

    $rkboptions = get_option('rkb_aws_options');
    $http = is_ssl() ? 'https' : 'http';
    $privateurl = $http.'://s3.amazonaws.com/'.$rkboptions['aws_bucket'].'/';
    $publicurl = $http.'://s3.amazonaws.com/'.$rkboptions['aws_public_bucket'].'/';
    $totalrows = count($rows);
	
    $limit = (int)get_option('rkb_import_limit'); // tune it to largest possible values, but don't burn the exhaust limit.
	if(!$limit){
		$limit = 500;
	}
	
    // as the value will increase, so will the execution time.
    $sqllimit = 100;
//    var_dump($totalrows); die();
    //$record_inserted = file_get_contents('record-inserted.txt'); // retrieve starting page number
	$records = get_option('rkb_import_record');
	if(isset($records[$importfile]) && $records[$importfile]){
		$record_inserted = $records[$importfile];
	}elseif(empty($records)){
		$records = array();
	}
	
    if(!isset($record_inserted)){
        $record_inserted = 0;
    }
	$escape = get_option('rkb_import_esc');
    $record_inserted = (int)$record_inserted;
    $start = $record_inserted < 1 ? (int)$escape : $record_inserted + 1;
    $end = $record_inserted + $limit <= $totalrows ? $record_inserted + $limit : $totalrows;
    //die('0');
    if($end <= $start){
		echo '0';
		die();
        //die('Sorry, all records have been inserted');
    }
	//var_dump('Inserting record from index '.$start.' to '.($end - 1).' index.');
	echo 'Inserting record from index '.$start.' to '.($end - 1).' index.<br />';
	
    $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    $affected = $loop = 0;
    
    $productsql .= "INSERT INTO `{$wpdb->posts}`("
                . "`post_author`,"
                . "`post_date`,"
                . "`post_date_gmt`,"
                . "`post_modified`,"
                . "`post_modified_gmt`,"
                . "`post_type`,"
                . "`post_status`,"
                . "`comment_status`,"
                . "`ping_status`,"
                . "`post_password`,"
                . "`to_ping`,"
                . "`pinged`,"
                . "`post_parent`,"
                . "`menu_order`,"
                . "`post_mime_type`,"
                . "`comment_count`,"
                . "`post_content_filtered`,"
                . "`post_title`,"
                . "`post_name`,"
                . "`guid`,"
                . "`post_content`,"
                . "`post_excerpt`"
                . ") VALUES";
    $product = array();
    $productTax = array();
    for($i = $start; $i < $end; $i++){
        $row = $rows->{$i};
        if(!isset($row->c))
            continue;
        $loop++;
        $productsql .= "(1, NOW(), NOW(), NOW(), NOW(), 'product', 'publish', 'open', 'close', '', '','', 0, 0, '', 0, '',";
        $c = $loop - 1;
        $product[$c] = array();
        $productTax[$c] = array();
        
        $catid = $subcatid = null;
        $tagslist = array();
        
        foreach($row->c as $col){
            $val = $xlsx->value($col);
            preg_match('/[A-Z]/', $col['r'], $colid);
            $colid = $colid[0];
            switch($colid){
                case 'A': // category
                //case 'B': // sub-category
                    $foundcat = get_term_by('name', $val, 'product_cat');
                    if(!empty($foundcat) && !is_wp_error($foundcat)){
                        if($colid == 'A'){
                            $catid = $foundcat;
                        }
//                        else{
//                            $subcatid = $foundcat;
//                        }
                    }else{
                        $termargs = array();
                        if(!empty($catid))
                            $termargs['parent'] = (int)$catid->term_id;
                        $newterm = wp_insert_term($val, 'product_cat', $termargs);
                        if(!empty($newterm) && !is_wp_error($newterm)){
                            $newterm = get_term((int)$newterm['term_id'], 'product_cat');
                            if($colid == 'A'){
                                $catid = $newterm;
                            }
//                            else{
//                                $subcatid = $newterm;
//                            }
                        }
                    }
                    break;
                case 'B': // title
//                    $check_sql = "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_title = '{$val}' AND post_type = 'product'";
//                    $countposts = $wpdb->get_var($check_sql);
                    $postname = preg_replace_callback('/[^\w\d]+/', function($m){ return "-";}, strtolower($val));
//                    if($countposts > 0){
                        $postname .= '-'.rand(000000,999999);
//                    }
                    $guid = home_url('/product/').$postname;
                    $productsql .= "'{$val}', '{$postname}', '{$guid}',";
                    $product[$c]['total_sales'] = 0;
                    $product[$c]['_virtual'] = 'yes';
                    $product[$c]['_visibility'] = 'visible';
                    $product[$c]['_weight'] = '';
                    $product[$c]['_length'] = '';
                    $product[$c]['_width'] = '';
                    $product[$c]['_height'] = '';
                    
                    $product[$c]['_sale_price'] = '';
                    $product[$c]['_sale_price_dates_from'] = '';
                    $product[$c]['_sale_price_dates_to'] = '';
                    
                    $product[$c]['_backorders'] = '';
                    $product[$c]['_manage_stock'] = 'no';
                    $product[$c]['_stock'] = '';
                    $product[$c]['_stock_status'] = 'instock';
                    $product[$c]['_downloadable'] = 'yes';
                    $product[$c]['_download_type'] = 'application';
                    $product[$c]['_wc_rating_count'] = serialize(array());
                    $product[$c]['_wc_average_rating'] = 0;
                    break;
                case 'C': // description
                    $val = addcslashes($val, '"\'');
                    $productsql .= "'{$val}', '{$val}'";
                    break;
                case 'D': // tags
                    $tags = explode(',', $val);
                    foreach($tags as $tag){
                        $tag = trim($tag);
                        $foundcat = get_term_by('name', $tag, 'product_tag');
                        if(!empty($foundcat) && !is_wp_error($foundcat)){
                            $tagslist[] = (int)$foundcat->term_taxonomy_id;
                        }else{
                            $newterm = wp_insert_term($tag, 'product_tag');
                            if(!empty($newterm) && !is_wp_error($newterm)){
                                $tagslist[] = (int)$newterm['term_taxonomy_id'];
                            }
                        }
                    }
                    break;
                case 'E': // duration
                        $product[$c]['_duration'] = $val;
                        break;
                case 'F': // price
                        $product[$c]['_price'] = $val;
                        $product[$c]['_regular_price'] = $val;
                        break;
                case 'G': // mp3 file
                case 'H': // wav file
                    $filename = $val;
                    if(!isset($product[$c]['_downloadable_files'])){
                        $product[$c]['_downloadable_files'] = array();
                    }
                    if($colid == 'G'){
                        $val = $publicurl.$val;
                        $product[$c]['public_audio_file'] = $val;
                    }else{
                        $val = $privateurl.$val;
                    }
                    $product[$c]['_downloadable_files'][md5($val)] = array(
                        'name' => $filename,
                        'file' => $val,
                    );
                    if($colid == 'H'){
                        $product[$c]['_downloadable_files'] = serialize($product[$c]['_downloadable_files']);
                    }
                    break;
                case 'I': //artist
                    $product[$c]['_artist'] = $val;
                    break;
                case 'J': //library
                    $product[$c]['_library'] = $val;
                    break;
                case 'M': //shortId
                    $product[$c]['_sku'] = $val;
                    break;
            }
        }
        
        if($loop % $sqllimit == 0 || $i == $end - 1){
            $productsql .= ');';
//            $wpdb->query($productsql);
//            $wpdb->flush();
            rkb_perform_mysql_query($productsql, $mysqli);
            //var_dump(__LINE__.':Mysqli Error:'.$mysqli->error.'-->'.$mysqli->errno);
            //var_dump('Affected Rows'.$mysqli->affected_rows);
            $affected += $mysqli->affected_rows;
            // do sql executions here.
            if($i < $end - 1){
                $productsql = "INSERT INTO `{$wpdb->posts}`("
                            . "`post_author`,"
                            . "`post_date`,"
                            . "`post_date_gmt`,"
                            . "`post_modified`,"
                            . "`post_modified_gmt`,"
                            . "`post_type`,"
                            . "`post_status`,"
                            . "`comment_status`,"
                            . "`ping_status`,"
                            . "`post_password`,"
                            . "`to_ping`,"
                            . "`pinged`,"
                            . "`post_parent`,"
                            . "`menu_order`,"
                            . "`post_mime_type`,"
                            . "`comment_count`,"
                            . "`post_content_filtered`,"
                            . "`post_title`,"
                            . "`post_name`,"
                            . "`guid`,"
                            . "`post_content`,"
                            . "`post_excerpt`"
                            . ") VALUES";
            }
        }else{
            $productsql .= "),\n";
        }
        $productTax[$c][] = (int)$simple->term_taxonomy_id;
        
        if(isset($catid) && !empty($catid)){
            $productTax[$c][] = (int)$catid->term_taxonomy_id;
        }
//        if(isset($subcatid) && !empty($subcatid)){
//            $productTax[$c][] = (int)$subcatid->term_taxonomy_id;
//        }
        if(isset($tagslist) && !empty($tagslist)){
            $productTax[$c] = array_merge($productTax[$c], $tagslist);
        }
        $catid = $subcatid = false;
        $tagslist = array();
//        product_tag, product_cat
    }
    // product meta insertion sql operations.
    
    //var_dump($affected.' products inserted in real.');
    $importproducts = $wpdb->get_results("SELECT * FROM {$wpdb->posts} WHERE "
    . "post_type='product' ORDER BY ID DESC LIMIT {$affected}");
    $wpdb->flush(); // clear all results
//    die('No need to do more now.... It is only for enquiry the data missing issue.');
    //var_dump($importproducts[0]);
    
    $allmetakeys = array (
        'total_sales',
        '_virtual',
        '_visibility',
        '_weight',
        '_length',
        '_width',
        '_height',
        '_regular_price',
        '_sale_price',
        '_sale_price_dates_from',
        '_sale_price_dates_to',
        '_price',
        '_backorders',
        '_manage_stock',
        '_stock',
        '_stock_status',
        '_downloadable',
        '_download_type',
        '_wc_rating_count',
        '_wc_average_rating',
        '_downloadable_files',
        'public_audio_file',
        '_artist',
        '_library',
        '_sku',
        '_duration',
    );
    $n = count($importproducts) - 1;
    $i = $j = 0;
    $totalcycles = count($importproducts) * count($allmetakeys);
    $totalcatcycles = count($productTax);
    $productmetasql .= "INSERT INTO {$wpdb->postmeta}(`post_id`,`meta_key`,`meta_value`) VALUES";
    $productcatsql .= "INSERT INTO {$wpdb->term_relationships}(`object_id`,`term_taxonomy_id`,`term_order`) VALUES";
    
    $productTaxListAll = array();
    foreach($importproducts as $post){
        $newid = (int)$post->ID;
        foreach($allmetakeys as $meta_key){
            $i++;
            if($i % $sqllimit == 0 || $totalcycles == $i){
                $productmetasql .= "({$newid}, '{$meta_key}', '".$product[$n][$meta_key]."');";
//                $wpdb->query($productmetasql);
//                $wpdb->flush();
                rkb_perform_mysql_query($productmetasql, $mysqli);
//                var_dump(__LINE__.':Mysqli Error:'.$mysqli->error.'-->'.$mysqli->errno);
//                var_dump('Affected Rows'.$mysqli->affected_rows);
                if($totalcycles > $i){
                    $productmetasql = "INSERT INTO {$wpdb->postmeta}(`post_id`,`meta_key`,`meta_value`) VALUES";
                }
            }else{
                $productmetasql .= "({$newid}, '{$meta_key}', '".$product[$n][$meta_key]."'),";
            }
        }
        // import categories, tags, product type
        $postterms = array_unique($productTax[$n]);
        $totalcatcycles += count($postterms);
        foreach($postterms as $tax){
            $j++;
            if(!in_array($tax, $productTaxListAll)){
                $productTaxListAll[] = $tax;
            }
            // need to implement proper conditions here. It is not completed.
            if($j % $sqllimit == 0 || $n == 0){
                $productcatsql .= "({$newid}, {$tax}, 0);";
//                $wpdb->query($productcatsql);
//                $wpdb->flush();
                rkb_perform_mysql_query($productcatsql, $mysqli);
                //var_dump(__LINE__.':Mysqli Error:'.$mysqli->error.'-->'.$mysqli->errno);
                //echo $productcatsql.'<br /><br />';
                //var_dump('Affected Rows'.$mysqli->affected_rows);
                
                if($totalcatcycles > $j){
                    $productcatsql = "INSERT INTO {$wpdb->term_relationships}(`object_id`,`term_taxonomy_id`,`term_order`) VALUES";
                }
            }else{
                $productcatsql .= "({$newid}, {$tax}, 0),";
            }
        }

//        wp_set_post_terms($newid, (int)$simple->term_id, 'product_type');
//        if(isset($productTax[$n]['cat']) || isset($productTax[$n]['subcat'])){
//            $catid = array($productTax[$n]['cat']);
//            if(isset($productTax[$n]['subcat']))
//                $catid[] = $productTax[$n]['subcat'];
//            wp_set_post_terms($newid, $catid, 'product_cat');
//        }
//        if(isset($productTax[$n]['tags']) && !empty($productTax[$n]['tags'])){
//            wp_set_post_terms($newid, $productTax[$n]['tags'], 'product_tag');
//        }
        $n--;
    }
    if(!empty($productTaxListAll)){
        
        foreach($productTaxListAll as $k => $tax){
            if(($k + 1) % $sqllimit == 0 || $k == count($productTaxListAll) - 1){
                rkb_perform_mysql_query($taxcountssql, $mysqli);
                //var_dump(__LINE__.':Mysqli Error:'.$mysqli->error.'-->'.$mysqli->errno);
                //var_dump('Affected Rows'.$mysqli->affected_rows);
                if($k < count($productTaxListAll) - 1){
                    $taxcountssql = "UPDATE `{$wpdb->term_taxonomy}` SET count = (SELECT COUNT(*) FROM `{$wpdb->term_relationships}` WHERE `term_taxonomy_id` = {$tax}) WHERE term_taxonomy_id = {$tax};\n";
                }
            }else{
                $taxcountssql .= "UPDATE `{$wpdb->term_taxonomy}` SET count = (SELECT COUNT(*) FROM `{$wpdb->term_relationships}` WHERE `term_taxonomy_id` = {$tax}) WHERE term_taxonomy_id = {$tax};\n";
            }
        }
    }
    $mysqli->close();
    echo absint(microtime(true) - $benchmark).' seconds have used to import'."<br />";
	$records[$importfile] = $record_inserted + $affected;
	update_option('rkb_import_record', $records);
    //file_put_contents('record-inserted.txt', $record_inserted + $affected);
	die();
}
function rkb_perform_mysql_query($query, $mysqli){
    if($mysqli->multi_query($query)){
        $dbLink = $mysqli;
        while($dbLink->more_results() && $dbLink->next_result()) {
            $extraResult = $dbLink->use_result();
            if($extraResult instanceof mysqli_result){
                $extraResult->free();
            }
        }
    }
}

//wp();