<?php
//define('WP_USE_THEMES', true);
include 'simplexlsx.class.php';
//include '../sound-effects/wp-load.php';
//add_action('wp', 'insert_custom_products', 10);
add_action('wp_ajax_rkb_perform_import_soundeffects', 'rkb_insert_custom_products', 10);

//WC()->api->includes();
//WC()->api->register_resources(new WC_API_Server( '/' ));
/*
It is an useful query
INSERT INTO `wp_postmeta`(post_id, meta_key, meta_value) 
SELECT p.ID, '_visibility', 'visible' FROM 
(SELECT ID FROM wp_posts WHERE post_type="product" ORDER BY `ID` DESC) p;
*/

error_reporting(1);
ini_set('display_errors', 1);

function rkb_get_term_by_name($name, $tax = 'product_cat'){
	global $wpdb;
	
	$name = trim($name);
	$getterm = $wpdb->get_row("SELECT * FROM `{$wpdb->terms}` t 
	INNER JOIN `{$wpdb->term_taxonomy}` tt 
	ON t.term_id=tt.term_id
	WHERE t.name='{$name}' AND tt.taxonomy='{$tax}'");
    $wpdb->flush(); // clear all results
	
	return $getterm;
}

function rkb_insert_custom_products(){
    global $wpdb, $RkbBlastDriveImport;    
    
    //die('Comment the line '.__LINE__.' to start again');
    set_time_limit(0);
    $benchmark = microtime(true);
	if(!isset($_POST['_wp_nonce']) || !wp_verify_nonce( $_POST['_wp_nonce'], 'rkb7743v45f' )){
		//die('Access Denied.');
		echo '-1';
		die();
	}
	
	$importfile = stripslashes(str_replace('../', '', $_POST['rkb_import_file']));
	$dirpath = $RkbBlastDriveImport->plugin_dir.'/upload';
	
	if(!file_exists($dirpath.'/'.$importfile)){
		//die($importfile.' doesn\'t found.');
		echo '-2';
		die();
	}
	
    $xlsx = new SimpleXLSX($dirpath.'/'.$importfile);
    $allsheets = $xlsx->sheetNames();
    if(empty($allsheets)){
        echo '-1';
		die();
    }
    $sheetids = array_keys($allsheets);
    $sheetid = array_shift($sheetids);

    $data = $xlsx->worksheet($sheetid);
    $rows = $data->sheetData->row;

    
    $simple = get_term_by('slug','simple','product_type');
    $productsql = $productmetasql = $productcatsql = $taxcountssql = '';
    
    // $rkboptions = get_option('rkb_aws_options');
    $http = is_ssl() ? 'https' : 'http';
    $awsbucket = get_option('rkb_aws_bucket');
    $privateurl = $http.'://s3.amazonaws.com/';
    if ($awsbucket) {
        $privateurl .= $awsbucket.'/';
    }
    // $privateurl = $http.'://s3.amazonaws.com/'.$rkboptions['aws_bucket'].'/';
    // $publicurl = $http.'://s3.amazonaws.com/'.$rkboptions['aws_public_bucket'].'/';
    $totalrows = count($rows);
    
    $limit = (int)get_option('rkb_import_limit'); // tune it to largest possible values, but don't burn the exhaust limit.
	if(!$limit){
		$limit = 500;
	}
	
    // as the value will increase, so will the execution time.
    $sqllimit = ceil($limit / 5);
    // var_dump(is_file($dirpath.'/'.$importfile)); die();
    //$record_inserted = file_get_contents('record-inserted.txt'); // retrieve starting page number
    $records = get_option('rkb_import_record');
	if(isset($records[$importfile]) && $records[$importfile]){
		$record_inserted = $records[$importfile];
	}elseif(empty($records)){
		$records = array();
	}
	
    if(!isset($record_inserted)){
        $record_inserted = 0;
    }
	$escape = get_option('rkb_import_esc');
    $record_inserted = (int)$record_inserted;
    $start = $record_inserted < 1 ? (int)$escape : $record_inserted + 1;
    //$end = $record_inserted + $limit <= $totalrows ? $record_inserted + $limit : $totalrows - (int)$escape;
    $end = $record_inserted + $limit <= $totalrows ? $record_inserted + $limit : $totalrows;
    //die('0');
    if($end <= $start){
        echo '0';
		die();
        //die('Sorry, all records have been inserted');
    }
	//var_dump('Inserting record from index '.$start.' to '.($end - 1).' index.');
	echo 'Inserting record from index '.$start.' to '.($end - 1).' index.<br />';
	
    $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    $affected = $loop = 0;
    
    $productsql .= "INSERT INTO `{$wpdb->posts}`("
                . "`post_author`,"
                . "`post_date`,"
                . "`post_date_gmt`,"
                . "`post_modified`,"
                . "`post_modified_gmt`,"
                . "`post_type`,"
                . "`post_status`,"
                . "`comment_status`,"
                . "`ping_status`,"
                . "`post_password`,"
                . "`to_ping`,"
                . "`pinged`,"
                . "`post_parent`,"
                . "`menu_order`,"
                . "`post_mime_type`,"
                . "`comment_count`,"
                . "`post_content_filtered`,"
                . "`post_title`,"
                . "`post_name`,"
                . "`guid`,"
                . "`post_content`,"
                . "`post_excerpt`"
                . ") VALUES";
    $product = array();
    $productTax = array();
	$totalcatcycles = 0;
	
    for($i = $start; $i < $end; $i++){
        $row = $rows->{$i};
        if(!isset($row->c))
            continue;
        $loop++;
        $productsql .= "(1, NOW(), NOW(), NOW(), NOW(), 'product', 'publish', 'open', 'close', '', '','', 0, 0, '', 0, '',";
        $c = $loop - 1;
        $product[$c] = array();
        $productTax[$c] = array();
        
        $catid = $subcatid = null;
        $tagslist = array();
        
        foreach($row->c as $col){
            $val = $xlsx->value($col);
            preg_match('/[A-Z]/', $col['r'], $colid);
            $colid = $colid[0];
            switch($colid){
                case 'E': // category
                //case 'B': // sub-category
					$val = trim($val);
					$catname = str_replace('&', '&amp;', $val);
                    
                    $foundcat = rkb_get_term_by_name($catname, 'product_cat');
					$catid = null;
                    if(!empty($foundcat) && !is_wp_error($foundcat)){
                        $catid = $foundcat;
                    }else{
                        $termargs = array();
                        $newterm = wp_insert_term($val, 'product_cat', $termargs);
                        if(!empty($newterm) && !is_wp_error($newterm)){
                            $newterm = get_term((int)$newterm['term_id'], 'product_cat');
                            $catid = $newterm;
                        }
                    }
                    if (isset($catid) && !is_wp_error($catid)) {
                        $product[$c]['cat'] = (int)$catid->term_taxonomy_id;
                        //$product[$c]['cat'] = $catid->term_id;
                        $totalcatcycles += 2; // because of category and product type simple
                    }
                    break;
                
                case 'F': // tags
					$val = addcslashes($val, '"\'');
					$val = trim($val);
                    $tags = explode(',', $val);
					$product[$c]['tags'] = $tagslist = array();
                    if(!empty($tags)){
						foreach($tags as $tag){
							$tag = trim($tag);
							$tagname = str_replace('&', '&amp;', $tag);
							$foundcat = rkb_get_term_by_name($tagname, 'product_tag');
							//$foundcat = get_term_by('name', $tag, 'product_tag');
							if(!empty($foundcat) && !is_wp_error($foundcat)){
								$tagslist[] = (int)$foundcat->term_taxonomy_id;
								//$tagslist[] = (int)$foundcat->term_id;
							}else{
								$newterm = wp_insert_term($tag, 'product_tag');
								if(!empty($newterm) && !is_wp_error($newterm)){
									$tagslist[] = (int)$newterm['term_taxonomy_id'];
									//$tagslist[] = (int)$newterm['term_id'];
								}
							}
						}
						if(count($tagslist) > 6){
							$tagslist = array_slice($tagslist, 0, 6); //reduce number of tags to only 6
						}
						$product[$c]['tags'] = $tagslist;
						$totalcatcycles += count($tagslist);
					}
                    break;
                case 'C': // duration
                        $product[$c]['_duration'] = trim($val);
                        break;
                case 'D': // price
                        $product[$c]['_price'] = trim($val);
                        $product[$c]['_regular_price'] = trim($val);
                        break;
                case 'A': // wav and mp3 files
                case 'B': 
					$val = trim(addcslashes($val, '"\''));
                    
                    if(!isset($product[$c]['_downloadable_files'])){
                        $product[$c]['_downloadable_files'] = array();
                    }
                    $val = str_replace(' ', '+', preg_replace_callback('/^ROOT\//', function($m){return'';}, $val));
                    $val = $privateurl.$val;
                    if($colid == 'B'){
                        $product[$c]['public_audio_file'] = $val;
                    }
                    $product[$c]['_downloadable_files'][md5($val)] = array(
                        'name' => '',
                        'file' => $val,
                    );
                    if($colid == 'B'){
                        $product[$c]['_downloadable_files'] = serialize($product[$c]['_downloadable_files']);
                    }
                    break;
                case 'G': // file names
					$val = addcslashes($val, '"\'');
                    $posttitle = $filename = trim($val);
                    $dfs = unserialize($product[$c]['_downloadable_files']);
                    
                    foreach($dfs as &$df){
                        $df['name'] = $filename;
                    }
                    $product[$c]['_downloadable_files'] = serialize($dfs);

                    $postname = preg_replace_callback('/[^\w\d]+/', function($m){ return "-";}, strtolower($posttitle));
                    $postname .= '-'.time();
					
                    $guid = home_url('/product/').$postname;
                    $productsql .= "'{$posttitle}', '{$postname}', '{$guid}','{$posttitle}','{$posttitle}'";
                    
                    break;
                case 'H': //artist and rest of the meta fields
					$val = addcslashes($val, '"\'');
                    
                    $product[$c]['_artist'] = trim($val);
                    $product[$c]['_sku'] = '';
                    $product[$c]['_library'] = '';

                    $product[$c]['total_sales'] = 0;
                    $product[$c]['_virtual'] = 'yes';
                    $product[$c]['_visibility'] = 'visible';
                    $product[$c]['_weight'] = '';
                    $product[$c]['_length'] = '';
                    $product[$c]['_width'] = '';
                    $product[$c]['_height'] = '';
                    
                    $product[$c]['_sale_price'] = '';
                    $product[$c]['_sale_price_dates_from'] = '';
                    $product[$c]['_sale_price_dates_to'] = '';
                    
                    $product[$c]['_backorders'] = '';
                    $product[$c]['_manage_stock'] = 'no';
                    $product[$c]['_stock'] = '';
                    $product[$c]['_stock_status'] = 'instock';
                    $product[$c]['_downloadable'] = 'yes';
                    $product[$c]['_download_type'] = 'application';
                    $product[$c]['_wc_rating_count'] = serialize(array());
                    $product[$c]['_wc_average_rating'] = 0;
                    break;
                
            }
        }
        
        if($loop % $sqllimit == 0 || $i == $end - 1){
            $productsql .= ');';

            rkb_perform_mysql_query($productsql, $mysqli);
			/*if($mysqli->errno){
				file_put_contents($dirpath.'/'.$importfile.'.txt', $productsql."\n".__LINE__.':Mysqli Error:'.$mysqli->error.'-->'.$mysqli->errno."\n".'Affected Rows'.$mysqli->affected_rows);
			}*/
            $affected += $mysqli->affected_rows;
            // do sql executions here.
            if($i < $end - 1){
                $productsql = "INSERT INTO `{$wpdb->posts}`("
                            . "`post_author`,"
                            . "`post_date`,"
                            . "`post_date_gmt`,"
                            . "`post_modified`,"
                            . "`post_modified_gmt`,"
                            . "`post_type`,"
                            . "`post_status`,"
                            . "`comment_status`,"
                            . "`ping_status`,"
                            . "`post_password`,"
                            . "`to_ping`,"
                            . "`pinged`,"
                            . "`post_parent`,"
                            . "`menu_order`,"
                            . "`post_mime_type`,"
                            . "`comment_count`,"
                            . "`post_content_filtered`,"
                            . "`post_title`,"
                            . "`post_name`,"
                            . "`guid`,"
                            . "`post_content`,"
                            . "`post_excerpt`"
                            . ") VALUES";
            }
        }else{
            $productsql .= "),\n";
        }
        /*$productTax[$c][] = (int)$simple->term_taxonomy_id;
        
        if(isset($catid) && !empty($catid)){
            $productTax[$c][] = (int)$catid->term_taxonomy_id;
        }*/
//        if(isset($subcatid) && !empty($subcatid)){
//            $productTax[$c][] = (int)$subcatid->term_taxonomy_id;
//        }
        /*if(isset($tagslist) && !empty($tagslist)){
            $productTax[$c] = array_merge($productTax[$c], $tagslist);
        }*/
        //$catid = $subcatid = false;
        //$tagslist = array();
//        product_tag, product_cat
    }
    // product meta insertion sql operations.
    
    //var_dump($affected.' products inserted in real.');
    $importproducts = $wpdb->get_results("SELECT * FROM {$wpdb->posts} WHERE "
    . "post_type='product' ORDER BY ID DESC LIMIT {$affected}");
    $wpdb->flush(); // clear all results
//    die('No need to do more now.... It is only for enquiry the data missing issue.');
    //var_dump($importproducts[0]);
    
    $allmetakeys = array (
        'total_sales',
        '_virtual',
        '_visibility',
        '_weight',
        '_length',
        '_width',
        '_height',
        '_regular_price',
        '_sale_price',
        '_sale_price_dates_from',
        '_sale_price_dates_to',
        '_price',
        '_backorders',
        '_manage_stock',
        '_stock',
        '_stock_status',
        '_downloadable',
        '_download_type',
        '_wc_rating_count',
        '_wc_average_rating',
        '_downloadable_files',
        'public_audio_file',
        '_artist',
        '_library',
        '_sku',
        '_duration',
    );
    $n = count($importproducts) - 1;
    $i = $j = 0;
    $totalcycles = count($importproducts) * count($allmetakeys);
    //$totalcatcycles = count($productTax);
    $productmetasql = "INSERT INTO {$wpdb->postmeta}(`post_id`,`meta_key`,`meta_value`) VALUES";
    $productcatsql = "INSERT INTO {$wpdb->term_relationships}(`object_id`,`term_taxonomy_id`,`term_order`) VALUES";
    
    $productTaxListAll = array();
	$ecatc = 0;
	
    foreach($importproducts as $post){
        $newid = (int)$post->ID;
        foreach($allmetakeys as $meta_key){
            $i++;
            if($i % $sqllimit == 0 || $totalcycles == $i){
                $productmetasql .= "({$newid}, '{$meta_key}', '".$product[$n][$meta_key]."');";

                rkb_perform_mysql_query($productmetasql, $mysqli);
                
                if($totalcycles > $i){
                    $productmetasql = "INSERT INTO {$wpdb->postmeta}(`post_id`,`meta_key`,`meta_value`) VALUES";
                }
            }else{
                $productmetasql .= "({$newid}, '{$meta_key}', '".$product[$n][$meta_key]."'),";
            }
        }
        // import categories, tags, product type
        $postterms = array( $simple->term_taxonomy_id, $product[$n]['cat']);
		if($product[$n]['tags']){
			$postterms = array_merge($postterms, $product[$n]['tags']);
		}
		$postterms = array_unique($postterms);
        //$totalcatcycles += count($postterms);
		
        foreach($postterms as $taxonomy => $tax){
			$j++;
            if(!in_array($tax, $productTaxListAll)){
                $productTaxListAll[] = $tax;
            }
            // need to implement proper conditions here. It is not completed.
			
            if($j % $sqllimit == 0 || $totalcatcycles == $j){
                $productcatsql .= "({$newid}, {$tax}, 0)";
				$productcatsql .= ";";
                rkb_perform_mysql_query($productcatsql, $mysqli);
				if($mysqli->error){
					$ecatc++;
					$econt = @file_get_contents($dirpath.'/'.$importfile.'.txt');
					@file_put_contents($dirpath.'/'.$importfile.'.txt', $ecatc.') '.$mysqli->error."\n".$productcatsql."\n\n".$econt);
				}
                if($totalcatcycles > $j){
                    $productcatsql = "INSERT INTO {$wpdb->term_relationships}(`object_id`,`term_taxonomy_id`,`term_order`) VALUES";
                }
            }elseif($totalcatcycles > $j){
                $productcatsql .= "({$newid}, {$tax}, 0),";
            }
        }
		
        $n--;
    }
	//@file_put_contents($dirpath.'/'.$importfile.'.txt', $productcatsql."\n");
	
	
    if(!empty($productTaxListAll)){
        foreach($productTaxListAll as $k => $tax){
            if(($k + 1) % $sqllimit == 0 || $k == count($productTaxListAll) - 1){
                rkb_perform_mysql_query($taxcountssql, $mysqli);
                if($k < count($productTaxListAll) - 1){
                    $taxcountssql = "UPDATE `{$wpdb->term_taxonomy}` SET count = (SELECT COUNT(*) FROM `{$wpdb->term_relationships}` WHERE `term_taxonomy_id` = {$tax}) WHERE term_taxonomy_id = {$tax};\n";
                }
            }else{
                $taxcountssql .= "UPDATE `{$wpdb->term_taxonomy}` SET count = (SELECT COUNT(*) FROM `{$wpdb->term_relationships}` WHERE `term_taxonomy_id` = {$tax}) WHERE term_taxonomy_id = {$tax};\n";
            }
        }
    }
	
	
    $mysqli->close();
    echo absint(microtime(true) - $benchmark).' seconds have used to import'."<br />";
	$records[$importfile] = $record_inserted + $affected;
	update_option('rkb_import_record', $records);
    //@file_put_contents('record-inserted.txt', $record_inserted + $affected);
	die();
}
function rkb_perform_mysql_query($query, $mysqli){
    if($mysqli->multi_query($query)){
        $dbLink = $mysqli;
        while($dbLink->more_results() && $dbLink->next_result()) {
            $extraResult = $dbLink->use_result();
            if($extraResult instanceof mysqli_result){
                $extraResult->free();
            }
        }
    }else{
        $msg = '----------------'.date('Y-m-d H:i:s').'-------------------'."\n";
        $msg .= $mysqli->error."\n";
        $msg .= $query."\n";
        log_the_error($msg);
    }
}

function log_the_error($msg){
    $fp = fopen(__DIR__.'/log.txt', 'w');
    fwrite($fp, $msg);
    fwrite($fp, "\n");
    fclose($fp);
}

//wp();