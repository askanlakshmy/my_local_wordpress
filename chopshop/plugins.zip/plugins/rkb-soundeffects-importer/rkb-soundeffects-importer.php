<?php
/**
 * Plugin Name: Soundeffects Import from Excel 2007
 * Description: An useful plugin for importing product data from excelsheet. Exclusively built for soundeffects.com
 * Version: 1.0
 * Author: Rakibul Hasan
 * Requires at least: 4.5.3
 * Tested up to: 4.7.3
 *
 * Text Domain: rkb
 *
 * @package rkb-soundeffects-importer
 * @category Core
 * @author Rakibul Hasan
 */
class RkbBlastDriveImport{
	private $notification;
	public $plugin_dir;
	public function __construct(){
		$this->plugin_dir = dirname(__FILE__);
		add_action('admin_menu', array($this, 'register_submenus'));
		add_action('admin_init', array($this, 'save_settings'));
		add_action('admin_enqueue_scripts', array($this, 'load_admin_scripts'));
		
	}
	public function load_admin_scripts(){
		$currentscreen = get_current_screen();
		if($currentscreen->base == 'tools_page_rkb-import-tool'){
			wp_enqueue_script('rkb-import', plugins_url('/assets/js/import-data.js', __FILE__), array('jquery'), false, true);
		}
	}
	public function register_submenus(){
		add_options_page( 
			'Soundeffects Import Settings',
			'Soundeffects Import Settings',
			'manage_options',
			'rkb-import-options',
			array($this,'rkb_import_options')
		);
		add_management_page( 
			'Import Soundeffects',
			'Import Soundeffects',
			'import',
			'rkb-import-tool',
			array($this,'rkb_import_tool')
		);
	}
	private function getFilesList(){
		$files = array();
		$dir = dirname(__FILE__).'/upload';
		if(is_dir($dir)){
			if($dh = opendir($dir)){
				while (($file = readdir($dh)) !== false) {
					if(!in_array($file, array('.', '..'))){
						$files[] = $file;
					}
				}
			}
			closedir($dh);
		}
		return $files;
	}
	public function rkb_import_tool(){
		?>
		<div class="wrap">
			<h1>Import Soundeffects</h1>
			<form id="import-soundeffects" method="post">
				<?php wp_nonce_field('rkb7743v45f', '_wp_nonce');?>
				<table class="form-table">
					<tbody>
						<tr>
							<th scope="row">
								<label for="blogname">Select file to import</label>
							</th>
							<td>
								<select name="rkb_import_file">
									<option value="">Select</option>
									<?php if($files = $this->getFilesList()){
										foreach($files as $file){
											echo '<option value="'.$file.'">'.$file.'</option>';
										}
									}?>
									
								</select>
							</td>
						</tr>
					</tbody>
				</table>
				<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Import">&nbsp;<span style="display:none;" class="status">Working...</span></p>
			</form>
			<div id="rkb-import-notice"></div>
			
		</div>
		<?php
	}
	public function save_settings(){
		if(isset($_POST['_wp_nonce']) && wp_verify_nonce( $_POST['_wp_nonce'], 'rkbsaveim475f' )){
			// it is perfect for saving options
			$limit = $_POST['rkb_import_limit'];
			$escape = $_POST['rkb_import_esc'];
			$bucket = $_POST['rkb_aws_bucket'];
			update_option('rkb_import_limit', $limit);
			update_option('rkb_import_esc', $escape);
			update_option('rkb_aws_bucket', $bucket);
			$this->notification = '<div id="setting-error-settings_updated" class="updated settings-error notice is-dismissible"> 
<p><strong>Settings saved.</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>';
		}
	}
	public function rkb_import_options(){
		$bucket = get_option('rkb_aws_bucket');
		$limit = get_option('rkb_import_limit');
		$escape = get_option('rkb_import_esc');
		if(!$limit){
			$limit = 500;
		}
		if(!$escape){
			$escape = 1;
		}
		?>
		<div class="wrap">
			<h1>Import Settings</h1>
			<?php echo $this->notification;?>
			<form method="post">
				<?php wp_nonce_field('rkbsaveim475f', '_wp_nonce');?>
				<table class="form-table">
					<tbody>
						<tr>
							<th scope="row">
								<label for="blogname">Amazon AWS Bucket Name</label>
							</th>
							<td>
								<input name="rkb_aws_bucket" type="text" id="rkb_aws_bucket" value="<?php echo $bucket;?>" class="regular-text"><br />
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="blogname">Insert Limit Per Cycle</label>
							</th>
							<td>
								<input name="rkb_import_limit" type="number" id="rkb_import_limit" value="<?php echo $limit;?>" class="regular-text"><br />
								<small><em>Note: lower numeric value is recommended and greater than 0</em></small>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="blogname">Escape row(s) initially</label>
							</th>
							<td>
								<input name="rkb_import_esc" type="number" id="rkb_import_esc" value="<?php echo $escape;?>" class="regular-text"><br />
								<small><em>Note: escape will only work first time where row starts from 0. Put numeric values only. Be careful when changing the value.</em></small>
							</td>
						</tr>
					</tbody>
				</table>
				<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save Changes"></p>
			</form>
		</div>
		<?php
	}
	
}

$RkbBlastDriveImport = new RkbBlastDriveImport();

require_once dirname(__FILE__).'/core/blastdrive.php';