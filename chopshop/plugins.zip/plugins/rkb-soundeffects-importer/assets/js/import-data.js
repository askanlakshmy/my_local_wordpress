(function($){
	$(document).ready(function(){
		var $form = $('#import-soundeffects');
		$form.on('submit', function(e){
			e.preventDefault();
			$doAjax();
		});
		var $doAjax = function(){
			var $data = {action: 'rkb_perform_import_soundeffects'};
			$data._wp_nonce = $form.find('[name="_wp_nonce"]').val();
			$data.rkb_import_file = $form.find('[name="rkb_import_file"]').val();
			if($data.rkb_import_file != ''){
				$form.find('span.status').show(300);
				$form.find('#submit').attr('disabled','disabled');
				
				$.ajax({
					url: ajaxurl,
					method: 'post',
					data: $data,
					success: function(resp){
						if(resp == '-1'){
							$form.siblings('#rkb-import-notice').prepend(
							'<div class="error settings-error notice is-dismissible">'+
							'<p><strong>Access Denied</strong></p></div>');
							$form.find('span.status').hide(300);
							$form.find('#submit').attr('disabled', null);
						}else if(resp == '-2'){
							$form.siblings('#rkb-import-notice').prepend(
							'<div class="error settings-error notice is-dismissible">'+
							'<p><strong>Invalid Or Empty File</strong></p></div>');
							$form.find('span.status').hide(300);
							$form.find('#submit').attr('disabled', null);
						}else if(resp != '0'){
							$form.siblings('#rkb-import-notice').prepend(
							'<div class="updated settings-error notice is-dismissible">'+
							'<p><strong>'+resp+'</strong></p></div>');
							$doAjax();
						}else{
							$form.siblings('#rkb-import-notice').prepend(
							'<div class="error settings-error notice is-dismissible">'+
							'<p><strong>Request not completed. Maybe the file has been imported already.</strong></p></div>');
							$form.find('span.status').hide(300);
							$form.find('#submit').attr('disabled', null);
						}
					}
				});
			}else{
				alert('Please select a file from dropdown.');
			}
		};
	});
})(jQuery);