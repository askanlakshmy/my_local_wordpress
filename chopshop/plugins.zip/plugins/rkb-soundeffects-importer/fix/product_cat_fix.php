<?php

include __DIR__.'/../../../../wp-load.php';

error_reporting(1);
ini_set('display_errors', 1);
set_time_limit(0);

if(!function_exists('rkb_get_term_by_name')){
    function rkb_get_term_by_name($name, $tax = 'product_cat')
    {
        global $wpdb;

        $name = trim($name);
        $getterm = $wpdb->get_row("SELECT * FROM `{$wpdb->terms}` t 
        INNER JOIN `{$wpdb->term_taxonomy}` tt 
        ON t.term_id=tt.term_id
        WHERE t.name='{$name}' AND tt.taxonomy='{$tax}'");
        $wpdb->flush(); // clear all results

        return $getterm;
    }
}
if(!function_exists('rkb_get_prod_by_name')){
    function rkb_get_prod_by_name($name)
    {
        global $wpdb;

        $name = trim($name);
        $post = $wpdb->get_row("SELECT * FROM `{$wpdb->posts}` 
        WHERE post_title LIKE '{$name}' AND post_type='product'");
        $wpdb->flush(); // clear all results

        return $post;
    }
}

if (isset($_REQUEST['rkb_import_file']) && $_REQUEST['rkb_import_file']) {
    $importfile = stripslashes(str_replace('../', '', $_REQUEST['rkb_import_file']));
    $dirpath = dirname(__FILE__).'/../upload';
    if(!file_exists($dirpath.'/'.$importfile)){
		//die($importfile.' doesn\'t found.');
		echo 'File doesn\'t exist!';
		die();
	}
    $xlsx = new SimpleXLSX($dirpath.'/'.$importfile);
    $allsheets = $xlsx->sheetNames();
    if(empty($allsheets)){
        echo 'Spreadsheet is empty';
		die();
    }
    $sheetids = array_keys($allsheets);
    $sheetid = array_shift($sheetids);

    $data = $xlsx->worksheet($sheetid);
    $rows = $data->sheetData->row;

    $totalrows = count($rows);

    if(!isset($record_inserted)){
        $record_inserted = 0;
    }
	$escape = get_option('rkb_import_esc');
    $record_inserted = (int)$record_inserted;
    $start = $record_inserted < 1 ? (int)$escape : $record_inserted + 1;

    $rowlimit = 50;


    for($i = $start; $i < $totalrows; $i++){
        
        if(($i + 1) % $rowlimit == 0){
            $wpdb->flush(); // clear all results
        }

        $row = $rows->{$i};

        if(!isset($row->c))
            continue;

        $catname = $xlsx->value($row->c[4]);
        $ptitle = $xlsx->value($row->c[6]);
        $catname = str_replace('&', '&amp;', $catname);
        
        $foundcat = rkb_get_term_by_name($catname);
        $prod = rkb_get_prod_by_name($ptitle);
        
        if(empty($prod) || is_wp_error($prod)){
            continue;
        }
        if(empty($foundcat) || is_wp_error($foundcat)){
            $termargs = array();
            $newterm = wp_insert_term($catname, 'product_cat', $termargs);
            if (!empty($newterm) && !is_wp_error($newterm)) {
                $foundcat = get_term((int)$newterm['term_id'], 'product_cat');
            }else{
                continue;
            }
        }
        wp_set_post_terms($prod->ID, $foundcat->term_id, 'product_cat');
    }
    echo 'Fixing done! Import file was '.$importfile;
}

function rkbGetFilesList(){
    $files = array();
    $dir = dirname(__FILE__).'/../upload';
    if(is_dir($dir)){
        if($dh = opendir($dir)){
            while (($file = readdir($dh)) !== false) {
                if(!in_array($file, array('.', '..'))){
                    $files[] = $file;
                }
            }
        }
        closedir($dh);
    }
    return $files;
}
?>
<form method="post">
    <p>
    <label>Select An Upload File</label>
    <select name="rkb_import_file">
        <option value="">Select</option>
        <?php if($files = rkbGetFilesList()){
            foreach($files as $file){
                echo '<option value="'.$file.'">'.$file.'</option>';
            }
        }?>
        
    </select>
    </p>
    <p>
        <button type="submit">Fix</button>
    </p>
</form>

