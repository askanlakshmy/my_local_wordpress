<?php
/*
Plugin Name: ChopShopFx Subscription
Plugin URI: https://dhakait.com.bd
Description: ChopShopFx subscription management
Author: CenturyCoding
Version: 1.0
Author URI: https://dhakait.com.bd
*/

/** filter for insert_user_meta */

/* SwpmMemberUtils::get_logged_in_members_level() */
// var_dump($member->membership_level);


function rkb_chopshop_check_valid_email($email){
	$email = explode('@', $email);
	if (isset($email[1]) && $email[1]) {
		$domain = $email[1];
		$regex = get_option('rkb_bb_email_regex');
		if ($regex) {
			$regex = preg_split('/[\,\;]/', $regex);
			return in_array($domain, $regex);
		}
	}
	return true;
}


// add_action('init', 'century_chopshopfx_subs_init', 11);

function century_chopshopfx_subs_init()
{
	remove_filter( 'register_url', 'bp_get_signup_page' );
	add_filter( 'register_url', function($url){
		$page_id = get_option('rkb_chopshop_reg_page');
		return ($page_id ? get_permalink((int)$page_id): $url);
	}, 11 );
}

add_action('init', 'century_chopshopfx_membership_submission', 1);

function century_chopshopfx_membership_submission(){
	if(is_admin()){
		return;
	}
	if(
		isset($_POST['swpm_registration_submit'])
		&& isset($_POST['swpm_level_hash'])
		&& isset($_POST['membership_level'])
		&& isset($_POST['email'])
		&& class_exists('SwpmUtils')
	){
		$free_membership_id = get_option('rkb_chopshop_free_membership');
		
		if($free_membership_id && in_array($_POST['membership_level'], $free_membership_id) && filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL)){
			$email = $_POST['email'];
			if (!rkb_chopshop_check_valid_email($email)) {
				$membership = SwpmUtils::get_membership_level_row_by_id((int)$_POST['membership_level']);
				$msg = 'Sorry, '.$_POST['email']. ' doesn\'t allowed for "'.$membership->alias.'" membership!';
				// $msg = var_export(in_array('st.fullsail.com', $regex), true);
				wp_die($msg);
			}
		}
	}
}


add_action('bp_signup_validate', 'rkb_chopshop_buddyboss_signup_validate');

function rkb_chopshop_buddyboss_signup_validate(){
	if ( isset( $_POST['signup_submit'] ) && bp_verify_nonce_request( 'bp_new_signup' ) ) {
		$bp = buddypress();
		$email = bp_get_signup_email_value();
        if (!rkb_chopshop_check_valid_email($email)) {
            $bp->signup->errors['signup_email'] = sprintf(esc_html__('Sorry, the email %1$s is not allowed to register here.', 'buddyboss'), $email);
        }
	}
}

/** shortcode */
add_shortcode('chopshop_payment_button', 'century_chopshop_payment_button');

function century_chopshop_payment_button($args = array()){
	global $wpdb;
	$args = shortcode_atts(array(
		'id' => '',
		'button_text' => '',
		'new_window' => '',
		'class' => '',
	), $args);

	$free_membership_id = get_option('rkb_chopshop_free_membership');
	$alt_membership_id = get_option('rkb_chopshop_alt_membership');
	if (is_user_logged_in()) {
		$current_user = wp_get_current_user();
		$member = SwpmMemberUtils::get_user_by_email($current_user->user_email);
		// membership_level_id meta_key, post_type swpm_payment_button
		$level = $member->membership_level;
		if(in_array($level, array(
			$free_membership_id, 
			$alt_membership_id
		))){
			$id_button = $wpdb->get_var("SELECT p.ID FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON p.ID=pm.post_id WHERE pm.meta_key='membership_level_id' AND pm.meta_value='{$alt_membership_id}'");
			if ($id_button) {
				$args['id'] = $id_button;
			}
		}
	}
	$shortcode = '[swpm_payment_button';
	foreach($args as $key=>$val){
		$shortcode .= ' '.$key.'="'.$val.'"';
	}
	$shortcode .= ']';
	return do_shortcode($shortcode);

}


function century_chopshopfx_admin_options(){

	global $wpdb;
	$table = $wpdb->prefix.'bp_xprofile_fields';
	$get_types_fields = $wpdb->get_results("SELECT id,name FROM {$table}", ARRAY_A);

	$subject = get_option('rkb_chopshop_email_subject');
	$gift_message = get_option('rkb_chopshop_gift_message');
	$regex = get_option('rkb_bb_email_regex');
	$field_course_end = get_option('rkb_bb_field_course_start');
	$field_course_duration = get_option('rkb_bb_field_course_duration');

	$free_membership_id = get_option('rkb_chopshop_free_membership');
	$alt_membership_id = get_option('rkb_chopshop_alt_membership');
	$rkb_chopshop_reg_page = get_option('rkb_chopshop_reg_page');

	$get_types_fields = array_merge(array(array('name'=>'None')), $get_types_fields);

	if($regex){
		$regex = str_replace('\\\\', '\\', $regex);
		
		// var_dump($regex);
		// var_dump(preg_match('/'.$regex.'/', "chopshop-test@fullsail.com", $match));
		// var_dump(preg_match('/'.$regex.'/', "testsubject6@student.fullsail.edu", $match));
		// var_dump(preg_match('/'.$regex.'/', "testsubject6@student.m_d0.fullsail.edu", $match));
	}
	
	?>
	<div class="wrap">
		<h1>ChopShopFx Subscription Settings</h1>
		<form method="post">
			<?php wp_nonce_field('rkbsaveim475f', '_wp_nonce');?>
			<table class="form-table">
				<tbody>
					<tr>
						<th scope="row">
							<label for="blogname">Free Subscription Course Start Field From Buddyboss</label>
						</th>
						<td>
							<select name="rkb_bb_field_course_start" class="regular-text">
								<?php foreach($get_types_fields as $field){
									$selected = '';
									if(isset($field['id']) && $field['id'] == $field_course_end){
										$selected = ' selected="selected"';
									}
									echo '<option value="'.(isset($field['id']) ? $field['id']:null).'"'.$selected.'>'.$field['name'].'</option>';
								}?>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="blogname">Free Subscription Course Duration Field From Buddyboss</label>
						</th>
						<td>
							<select name="rkb_bb_field_course_duration" class="regular-text">
								<?php foreach($get_types_fields as $field){
									$selected = '';
									if(isset($field['id']) && $field['id'] == $field_course_duration){
										$selected = ' selected="selected"';
									}
									echo '<option value="'.(isset($field['id']) ? $field['id']:null).'"'.$selected.'>'.$field['name'].'</option>';
								}?>
							</select>
						</td>
					</tr>
					<?php if(class_exists('SwpmUtils')){?>
					<tr>
						<th scope="row">
							<label for="blogname">Free Subscription Membership</label>
						</th>
						<td>
							<select name="rkb_chopshop_free_membership[]" multiple="true" class="regular-text">
								<?php 
								$query  = 'SELECT alias, id FROM ' . $wpdb->prefix . 'swpm_membership_tbl WHERE id != 1';
								$levels = $wpdb->get_results( $query );
                                foreach ($levels as $level) {
                                     echo '<option ' . ( in_array($level->id, $free_membership_id) ? 'selected="selected"' : '' ) . ' value="' . $level->id . '" >' . $level->alias . '</option>';
								}
								?>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="blogname">Alternative Membership</label>
						</th>
						<td>
							<select name="rkb_chopshop_alt_membership" class="regular-text">
								<?php echo SwpmUtils::membership_level_dropdown($alt_membership_id)?>
							</select>
						</td>
					</tr>
					
					<?php }?>
					<tr>
						<th scope="row">
							<label for="blogname">Membership Register Page</label>
						</th>
						<td>
							<?php
							echo wp_dropdown_pages( array(
								'name'             => 'rkb_chopshop_reg_page',
								'echo'             => false,
								'show_option_none' => __( '- Select a page -', 'buddyboss' ),
								'selected'         => ! empty( $rkb_chopshop_reg_page ) ? $rkb_chopshop_reg_page : false
							) );
							
							?>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="blogname">Free Subscription Email Regex</label>
						</th>
						<td>
							<input name="rkb_bb_email_regex" type="text" id="rkb_bb_email_regex" value="<?php echo $regex;?>" class="regular-text"><br />
							<small><em>Set Allowed Email Pattern For Free Subscription</em></small>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="blogname">After Subscription Offer Email Subject</label>
						</th>
						<td>
							<input name="rkb_chopshop_email_subject" type="text" id="rkb_chopshop_email_subject" value="<?php echo $subject;?>" class="regular-text"><br />
							<small><em>Set email subject text after subscription</em></small>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="blogname">After Subscription Offer Email Message</label>
						</th>
						<td>
							<textarea rows="10" cols="50" name="rkb_chopshop_gift_message" id="rkb_chopshop_gift_message" class="regular-text"><?php echo $gift_message;?></textarea><br />
							<small><em>Set email message text after subscription</em></small>
						</td>
					</tr>
				</tbody>
			</table>
			<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save Changes"></p>
		</form>
	</div>
	<?php
}

function century_chopshopfx_admin_init(){

	// $bp = buddypress();
	// require_once trailingslashit( $bp->plugin_dir  . 'bp-core/classes' ) . '/class-bp-admin-tab.php';
	// require_once trailingslashit( $bp->plugin_dir  . 'bp-core/classes' ) . '/class-bp-admin-setting-tab.php';

	if(isset($_POST['_wp_nonce']) && wp_verify_nonce( $_POST['_wp_nonce'], 'rkbsaveim475f' )){
		// it is perfect for saving options
		$data1 = $_POST['rkb_bb_field_course_start'];
		$data2 = $_POST['rkb_bb_email_regex'];
		$data3 = $_POST['rkb_bb_field_course_duration'];
		$data4 = $_POST['rkb_chopshop_gift_message'];
		$data5 = $_POST['rkb_chopshop_email_subject'];
		$data6 = $_POST['rkb_chopshop_reg_page'];
		$data7 = $_POST['rkb_chopshop_free_membership'];
		$data8 = $_POST['rkb_chopshop_alt_membership'];
		
		update_option('rkb_bb_field_course_start', $data1);
		update_option('rkb_bb_email_regex', $data2);
		update_option('rkb_bb_field_course_duration', $data3);
		update_option('rkb_chopshop_gift_message', $data4);
		update_option('rkb_chopshop_email_subject', $data5);
		update_option('rkb_chopshop_reg_page', $data6);
		update_option('rkb_chopshop_free_membership', $data7);
		update_option('rkb_chopshop_alt_membership', $data8);
	}

}
function century_chopshopfx_admin_menu(){

	add_options_page( 
		'ChopShopFx BuddyBoss Settings',
		'ChopShopFx BuddyBoss Settings',
		'manage_options',
		'century-chopshopfx-options',
		'century_chopshopfx_admin_options'
	);
}

function century_chopshopfx_bp_after_active($user_id, $key, $user){
	
	$startfield = get_option('rkb_bb_field_course_start');
	$regex = get_option('rkb_bb_email_regex');
	$durationfield = get_option('rkb_bb_field_course_duration');

	// file_put_contents(dirname(__FILE__).'/activated-user.txt', __LINE__);
	
	$userdata = get_userdata($user['user_id']);
	$user_email = $userdata->user_email;
	
	// file_put_contents(dirname(__FILE__).'/activated-user.txt', __LINE__);
	
	
    if ($regex) {
		// $regex = str_replace('\\\\', '\\', $regex);
		// $matched = (bool)preg_match($regex, $user_email);
		$date_a = $date_b = '';
		$regex = preg_split('/[\,\;]/', $regex);
		$email = explode('@', $user_email);
		$matched = in_array($email[1], $regex);
		// file_put_contents(dirname(__FILE__).'/activated-user.txt', __LINE__);
		if($matched){
			// file_put_contents(dirname(__FILE__).'/activated-user.txt', __LINE__);
			foreach($user['meta'] as $meta_key=>$meta_value){
				if(str_replace('field_', '', $meta_key) == $durationfield){
					$date_b = $meta_value;
					// file_put_contents(dirname(__FILE__).'/activated-user.txt', __LINE__);
				}elseif(str_replace('field_', '', $meta_key) == $startfield){
					$date_a = $meta_value;
					// file_put_contents(dirname(__FILE__).'/activated-user.txt', __LINE__);
				}
			}

			$newdate = date('Y-m-d', strtotime("{$date_a}+{$date_b} Months")); // free subscription validity date
			update_user_meta($user_id, '_chopshop_subscription_ends', $newdate);
			century_chopshopfx_send_after_subs_msg($userdata);
		}
	}
}
function century_chopshopfx_send_after_subs_msg($userdata){
	$msg = get_option('rkb_chopshop_gift_message');
	if(!empty($msg) && preg_match('/[\w\d]+/', $msg)){
		// work here
		$subject = get_option('rkb_chopshop_email_subject');
		$headers = '';
		if(preg_match('/(<\/.*?>)+/', $msg)){
			$headers = array('Content-Type: text/html; charset=UTF-8');
		}
		wp_mail( $userdata->user_email, $subject, $msg, $headers );
	}
}
function century_chopshopfx_audio_download_links($product){
	
	if(is_user_logged_in() && is_a($product, 'WC_Product')){
		// compare user/subscriber _chopshop_subscription_ends meta with current date
		$current_user = wp_get_current_user();
		// disabled temporarily 22nd, January, 2020
		
		// $enddate = get_user_meta($current_user->ID, '_chopshop_subscription_ends', true);
		// if(!$enddate || time() > strtotime($enddate)){
		// 	return false;
		// }

		/** membership change 27-04-2020 */
		// if (class_exists('SwpmMemberUtils')) {
        //     $member = SwpmMemberUtils::get_user_by_email($current_user->user_email);
		// 	$expired = SwpmUtils::is_subscription_expired($member);
		// 	$expired |= $member->account_state != 'active';
		// 	if(current_user_can( 'administrator' )){
		// 		$expired = false;
		// 	}
			
		// }else{
		// 	$expired = false;
		// }
		$expired = false;
		
		if(!$expired){
			$urldownload = home_url('/');

			$downloads = $product->get_downloads();
			$k = 0;
			foreach($downloads as $download){
				$fileid = $download->get_id();
				$fileurl = $download->get_file();
				$extension = strtoupper(substr($fileurl, strrpos($fileurl, '.')+1));
				$urlparts = http_build_query(array(
					'action' => 'chopshopfx_download',
					'id_product' => $product->get_id(),
					'download' => $fileid,
				));
				if($k > 0){
					echo '&nbsp;';
				}
				echo '<a class="btn btn-download '.$extension.'" target="_blank" href="'.$urldownload.'?'.$urlparts.'">'.sprintf(esc_html__("%s","chopshopfx-subscription"), $extension).'</a>';
				$k++;
			}
		}
	}
}

function century_chopshopfx_audio_download(){
	if(is_user_logged_in() && isset($_REQUEST['action']) && $_REQUEST['action'] == 'chopshopfx_download'){
		// compare user/subscriber _chopshop_subscription_ends meta with current date
		// disabled expiration checking for logged in users
		$current_user = wp_get_current_user();
		// $enddate = get_user_meta($current_user->ID, '_chopshop_subscription_ends', true);

		/** membership change 27-04-2020 */
        // if (class_exists('SwpmMemberUtils')) {
        //     $member = SwpmMemberUtils::get_user_by_email($current_user->user_email);
		// 	$expired = SwpmUtils::is_subscription_expired($member);
		// 	$expired |= $member->account_state != 'active';
		// 	if(current_user_can( 'administrator' )){
		// 		$expired = false;
		// 	}
		// }else{
		// 	$expired = false;
		// }

		$expired = false;
		
		if(!$expired){
			$id_product = (int)$_REQUEST['id_product'];
			$dfileid = $_REQUEST['download'];
			if($id_product){
				$product = wc_get_product( $id_product );
				$downloads = $product->get_downloads();
				foreach($downloads as $k=>$download){
					
					if($dfileid == $download->get_id()){
						// get content from amazon aws and set download headers
						$fileurl = $download->get_file();
						$filename = $download->get_name();
						$extension = strtolower(substr($fileurl, strrpos($fileurl, '.')+1));
						if($extension == 'wav'){
							$mime = 'audio/x-wav';
						}else{
							$mime = 'audio/mpeg';
						}
						$response = wp_remote_get($fileurl, array(
							'sslverify' => false,
							'timeout' => 30,
						));
						if(isset($mime) && $mime && $response['body']){
							header('Content-Type:'. $mime.'\r\n');
							header('Content-Disposition: attachment; filename="'. $filename.'.'.$extension.'"');
							echo $response['body'];
						}

						break;
					}
				}
			}
		}
		die();
	}
	
}

function century_chopshopfx_bp_init(){
	add_action('bp_core_activated_user', 'century_chopshopfx_bp_after_active', 11, 3);
}
function century_chopshopfx_bp_wp_init(){
	
	add_action('rkb_add_to_cart', 'century_chopshopfx_audio_download_links', 12, 1);
	//add separator div
	add_action('rkb_add_to_cart', function(){ echo '<div class="chopshop-player-buttons">';}, 2);
	add_action('rkb_add_to_cart', function(){ echo '</div><!--chopshop-player-buttons-->';}, 20);
	century_chopshopfx_audio_download();
	// add_action('wp_ajax_chopshopfx_download', 'century_chopshopfx_audio_download');
	// add_action('wp_ajax_nopriv_chopshopfx_download', 'century_chopshopfx_audio_download');
}

add_action('admin_menu', 'century_chopshopfx_admin_menu', 11);
add_action('admin_init', 'century_chopshopfx_admin_init', 11);
add_action('wp', 'century_chopshopfx_bp_wp_init', 11);
add_action('init', 'century_chopshopfx_bp_init');
