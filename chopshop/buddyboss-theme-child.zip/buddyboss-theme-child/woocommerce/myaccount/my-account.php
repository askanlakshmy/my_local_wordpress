<?php
/**
 * My Account page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/my-account.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

wc_print_notices();

/**
 * My Account navigation.
 * @since 2.6.0
 */
 
?>

<?php
    global $wp;
    $request = explode( '/', $wp->request );

    // If in My account dashboard page
    //echo "test";
                $id=get_current_user_id();
                $getstd = get_user_meta($id, 'wp_capabilities', true);
                $newArray = array_keys($getstd);
                //print_r($newArray);
                echo "<div class='container'>";
                echo "<div class='row'>";
                echo "<div class='col-md-3'>";
                if($newArray[0]=='student' || $newArray[1]=='student')
                {
                    echo "<img src='https://chopshopfx.com/wp-content/uploads/CSFXIconStudent1.png'/>";
                    echo "<b style='padding-left:10px;color:#ff9933;vertical-align: text-bottom;'>Student License</b>";
                }
                if($newArray[0]=='commercial' || $newArray[1]=='commercial')
                {
                   ?>

                    <img src='https://chopshopfx.com/wp-content/uploads/CSFXIconProfessional2.png'/>
                  <?php  
                  
                  echo "<b style='padding-left:10px;color:#ff9933;'>Professional License</b>";
                }
                echo "</div>";
                echo "<div class='col-md-3'>";
                $arr=[];
                $currrent_uid=get_current_user_id();
                $date_form=get_user_meta($currrent_uid,'course_duration',true);
                $arr=explode('/',$date_form);
                $date_form=$arr[0].'-'.$arr[1].'-'.$arr[2];
                $date=date_create($date_form);
                date_add($date,date_interval_create_from_date_string("30 days"));
                    $then = str_replace("/", "-", $date_form);
                    $then = strtotime($then);
                    $dbdate;
                    $now = time();
                    $difference = $then - $now;
                    $days = floor($difference / (60 * 60 * 24));
                    if($newArray[0]=='student' || $newArray[1]=='student')
                    {
                    if($days<-31)
                    {
                        //color:red;text-align:right;margin-top: -4%;margin-bottom: 7px;font-size: 15px;
                        
                        echo "<p  class='license-expiry-date'>License Expiration Date: ".date_format($date,"j-F-Y").' (Licence Expired)'; 
                    }
                    else{
                        echo "<p  class='license-expiry-date-cnt'>License Expiration Date: ".date_format($date,"j-F-Y").' ('.($days+32).' Days Remaining)';
                    }
                    }
                    ?>
                      </div>
                    </div>
                    </div>
<?php                
    if( ( end($request) == 'my-account' && is_account_page() ) ){ 
    
        $dashBoardClass = "bsMyAccount--dashboard";
     
    } else {
        
        $dashBoardClass = "bsMyAccount--dashboard-inner";
        
    }
?>

<div class="bsMyAccount <?php echo $dashBoardClass; ?>">
    <?php
    do_action( 'woocommerce_account_navigation' ); ?>
    
    <div class="woocommerce-MyAccount-content">
    	<?php
    		/**
    		 * My Account content.
    		 * @since 2.6.0
    		 */
    		do_action( 'woocommerce_account_content' );
    	?>
    </div>
</div>
