<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package BuddyBoss_Theme
 */

?>

<?php do_action( THEME_HOOK_PREFIX . 'end_content' ); ?>

</div><!-- .bb-grid -->
</div><!-- .container -->
</div><!-- #content -->

<?php do_action( THEME_HOOK_PREFIX . 'after_content' ); ?>

<?php do_action( THEME_HOOK_PREFIX . 'footer' ); ?>

</div><!-- #page -->

<?php do_action( THEME_HOOK_PREFIX . 'after_page' ); 

  ?>
<script type="text/javascript">
jQuery(document).ready(function() {
    var downloadvalue=jQuery("#dwnlink").val();
    jQuery("#showCheckoutHistory").change(function() {
                    var ischecked= jQuery(this).is(':checked');
                    var ischeckedtwo= jQuery(this).is(":not(:checked)");
                    console.log(ischeckedtwo);
                    console.log(ischecked);
if(!ischeckedtwo)
{
    jQuery("#dwnlink").val(downloadvalue);
}
else 
{
    jQuery("#dwnlink").val("");
     console.log("else part");
}
            
                //     console.log(ischeckedtwo);
                //     console.log(ischecked);
                //     if(ischecked)
                //     {
                //         console.log("if part");
                //         jQuery("#downlod_link").show(); 
                //     }
                //     else if(ischeckedtwo)
                //     {
                //         console.log("else part");
                //         jQuery("#downlod_link").hide();  
                //     }
                // }); 
});
});


</script>
<?php if(is_page(436)): ?>
<script>
<?php $site_url=site_url();?>
if(document.URL=="<?php echo $site_url; ?>/my-account/downloads-sfx/")
{
setInterval(function(element) {
  
  

  
  
            devtoolsOpen = false;
            ///console.log(element);
            if (devtoolsOpen) {
                open(location, '_self').close();
            } else {
                console.log('close');
            }
        }, 500);
        jQuery(document).keydown(function(event) {
            if (event.keyCode == 123) {
                return false;
            } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
                return false;
            }
            else if (event.ctrlKey && (event.keyCode === 67 || event.keyCode === 86 || event.keyCode === 85 || event.keyCode === 117)) {//Alt+c, Alt+v will also be disabled sadly.
              return false;
            }
            
        });
        jQuery(document).on("contextmenu", function(e) {
            e.preventDefault();
        });
}


</script>


        <?php endif; ?>
        <script>

jQuery(document).ready( function () {
  jQuery('#myTable').DataTable();
  
  
} );
        </script>
        
        <style>
            #myTable span {
        display:none;
        }
        </style>
        
        <?php if(is_page(22388)){
            ?>
        <script>
document.title ='<?php bloginfo('name'); echo " -"; echo " Register" ?>';
        </script>
        <?php } 
        
        if(is_page(22388))
        {
?>
<script src="https://chopshopfx.com/speed/wp-content/themes/buddyboss-theme/assets/js/vendors/magnific-popup.min.js?ver=1.2.2">
</script>
<?php 
        }
        ?>
      
<?php   wp_footer();  ?>   
</body>
</html>
