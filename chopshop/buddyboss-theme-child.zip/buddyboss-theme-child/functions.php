<?php
/**
 * @package BuddyBoss Child
 * The parent theme functions are located at /buddyboss-theme/inc/theme/functions.php
 * Add your own functions at the bottom of this file.
 */

/****************************** THEME SETUP ******************************/

/**
 * Sets up theme for translation
 *
 * @since BuddyBoss Child 1.0.0
 */
function buddyboss_theme_child_languages()
{
    /**
     * Makes child theme available for translation.
     * Translations can be added into the /languages/ directory.
     */

    // Translate text from the PARENT theme.
    load_theme_textdomain('buddyboss-theme', get_stylesheet_directory() . '/languages');

    // Translate text from the CHILD theme only.
    // Change 'buddyboss-theme' instances in all child theme files to 'buddyboss-theme-child'.
    // load_theme_textdomain( 'buddyboss-theme-child', get_stylesheet_directory() . '/languages' );

}
add_action('after_setup_theme', 'buddyboss_theme_child_languages');

/**
 * Enqueues scripts and styles for child theme front-end.
 *
 * @since Boss Child Theme  1.0.0
 */
function buddyboss_theme_child_scripts_styles()
{
    /**
     * Scripts and Styles loaded by the parent theme can be unloaded if needed
     * using wp_deregister_script or wp_deregister_style.
     *
     * See the WordPress Codex for more information about those functions:
     * http://codex.wordpress.org/Function_Reference/wp_deregister_script
     * http://codex.wordpress.org/Function_Reference/wp_deregister_style
     **/

    // Styles
    wp_enqueue_style('buddyboss-child-css', get_stylesheet_directory_uri() . '/assets/css/custom.css');
    wp_enqueue_style('datatable-css', 'http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css');
    // if(is_page())
    // Javascript
    wp_enqueue_script('buddyboss-child-js', get_stylesheet_directory_uri() . '/assets/js/custom.js');
    wp_enqueue_script('custom-register', get_stylesheet_directory_uri() . '/assets/js/custom_register.js');
    wp_enqueue_script('data-table-js', 'http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js');
}
add_action('wp_enqueue_scripts', 'buddyboss_theme_child_scripts_styles', 9999);

/****************************** CUSTOM FUNCTIONS ******************************/

// Add your own custom functions here

/* new product search function */
$rkb_chopshop_search_tag = null;

add_action('parse_query', 'rkb_override_product_search_actions', 30);

function rkb_override_product_search_actions($wp_query)
{
    if (is_search()
        && function_exists('WC')
        && isset($wp_query->query['post_type'])
        && $wp_query->query['post_type']) { //remove woocommerce search filter
        // remove_action( 'pre_get_posts', array( WC()->query, 'pre_get_posts' ) );
        add_filter('posts_clauses', 'rkb_override_wc_join_query', 11);
        add_filter('posts_where', 'rkb_alter_search_product_where');
        // add_filter('posts_orderby', 'rkb_alter_search_product_orderby');
    }
}

function rkb_override_wc_join_query($args)
{
    global $wpdb;
    $sql = ' INNER JOIN ' . $wpdb->term_relationships . ' tr ON ' . $wpdb->posts . '.ID=tr.object_id RIGHT JOIN ' .
    $wpdb->term_taxonomy . ' tt ON tr.term_taxonomy_id=tt.term_taxonomy_id INNER JOIN ' .
    $wpdb->terms . ' t ON tt.term_id=t.term_id';
    $args['join'] .= $sql;
    $args['orderby'] = ' t.name ASC ';
    return $args;
}

function rkb_alter_search_product_where($where = '')
{
    global $wp_the_query, $wpdb, $rkb_chopshop_search_tag;

    // Change the query
    // AND (((t89m1_posts.post_title LIKE '%distortion%') OR (t89m1_posts.post_excerpt LIKE '%distortion%') OR (t89m1_posts.post_content LIKE '%distortion%')))
    $keyword = $wp_the_query->query['s'];
    /* $new_where = " AND {$wpdb->posts}.post_status='publish'
    AND {$wpdb->posts}.post_type='product' ";*/

    // $wp_the_query->query_vars['search_orderby_title']

    // search product_tag
    $tags = get_terms(array('taxonomoy' => 'product_tag', 'name__like' => $keyword));

    if (!empty($tags) && !is_wp_error($tags)) {
        $rkb_chopshop_search_tag = array();
        foreach ($tags as $tag) {
            $rkb_chopshop_search_tag[] = $tag;
        }
    }

    $new_where = $where;

    /*$new_where .= " OR {$wpdb->posts}.ID IN(
    SELECT tr.object_id FROM {$wpdb->term_relationships} tr
    RIGHT JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id=tt.term_taxonomy_id
    INNER JOIN {$wpdb->terms} t ON tt.term_id=t.term_id
    WHERE t.name LIKE '%{$keyword}%'
    )";*/
    $new_where .= " OR t.name LIKE '%{$keyword}%'";
    $new_where .= " AND tt.taxonomy IN('product_cat', 'product_tag')";

    return $new_where;
}
function rkb_alter_search_product_orderby($orderby)
{
    global $wpdb;
    return " {$wpdb->posts}.post_title ASC";
}

add_filter('woocommerce_product_add_to_cart_text', 'rkb_bb_woocommerce_product_add_to_cart_text', 12, 1);

function rkb_bb_woocommerce_product_add_to_cart_text($text)
{
    // return esc_html__('More Info', 'buddyboss');
    return '';
}

add_filter('loop_shop_per_page', 'rkb_loop_shop_per_page', 11, 1);

function rkb_loop_shop_per_page($count)
{
    return 25;
}

/* update course duration  date custom*/

add_action('edit_user_profile', 'wk_custom_user_profile_fields');

function wk_custom_user_profile_fields($user)
{
    //echo '<h3 class="heading">Custom Fields</h3>';
    ?>
    <table class="form-table">
  <tr>
            <th><label for="contact">course Duration In Months</label></th>

      <td><input type="text" class="input-text form-control" name="degree_lengthtwo"  value="<?php echo get_user_meta($user->ID, 'degree_length', true); ?>" id="contact" />
            </td>

  </tr>
    </table>

    <?php
}

add_action('show_user_profile', 'wk_custom_user_profile_fields');
add_action('edit_user_profile_update', 'wk_save_custom_user_profile_fields');
//add_action( 'personal_options_update', 'wk_save_custom_user_profile_fields' );
/**
 *   @param User Id $user_id
 */
function wk_save_custom_user_profile_fields($user_id)
{

    global $wpdb;
    $custom_data = $_POST['degree_lengthtwo'];
    $get_entry = $wpdb->get_results("SELECT user_registered FROM `wp_users` WHERE ID='$user_id'");
    $st = $custom_data . ' months';
    $date = date_create($get_entry[0]->user_registered);
    date_add($date, date_interval_create_from_date_string($st));
    $course_durations = date_format($date, 'Y/m/d');
    update_user_meta($user_id, 'course_duration', $course_durations);
    update_user_meta($user_id, 'degree_length', $custom_data);
//exit;
}

/*
 * Step 1. Add Link (Tab) to My Account menu
 */
add_filter('woocommerce_account_menu_items', 'membership_links', 40);
function membership_links($menu_links)
{
    $id = get_current_user_id();
    $getstd = get_user_meta($id, 'wp_capabilities', true);
    $newArray = array_keys($getstd);
    if ($newArray[0] == 'student' || $newArray[1] == 'student') {
        global $wpdb;
        $download_lnk = $wpdb->get_results("SELECT autogenerate_key  FROM `wp_autogenerate_key` ");
        // print_r($download_lnk);
        $download_lnk[0]->autogenerate_key;
        foreach ($download_lnk as $dbld) {
            $dwnlk[] = $dbld->autogenerate_key;
        }
        $currentiduser = get_current_user_id();
        $keyck = get_user_meta($currentiduser, 'activation_key', true);
        if (in_array($keyck, $dwnlk)) {
            // echo "here";
            $chek = $wpdb->get_results("SELECT mail_check_link,mail_link  FROM `wp_autogenerate_key` where autogenerate_key='$keyck'");
            if ($chek[0]->mail_check_link == 'checked') {
                $menu_links = array_slice($menu_links, 0, 1, true)
                 + array('upgrade-subscription' => 'Upgrade Subscription') + array('downloads-sfx' => 'Download')
                 + array_slice($menu_links, 1, null, true);
            } else {
                $menu_links = array_slice($menu_links, 0, 1, true)
                 + array('upgrade-subscription' => 'Upgrade Subscription')
                 + array_slice($menu_links, 1, null, true);

            }
        } else {
            $menu_links = array_slice($menu_links, 0, 1, true)
             + array('upgrade-subscription' => 'Upgrade Subscription')
             + array_slice($menu_links, 1, null, true);
        }

        return $menu_links;
    } else if ($newArray[0] == 'commercial' || $newArray[1] == 'commercial') {
        global $wpdb;
        $download_lnk = $wpdb->get_results("SELECT autogenerate_key  FROM `wp_autogenerate_key` ");
// print_r($download_lnk);
        $download_lnk[0]->autogenerate_key;
        foreach ($download_lnk as $dbld) {
            $dwnlk[] = $dbld->autogenerate_key;
        }
        $currentiduser = get_current_user_id();
        $keyck = get_user_meta($currentiduser, 'activation_key', true);
        if (!in_array($keyck, $dwnlk)) {
            $chek = $wpdb->get_results("SELECT mail_check_link,mail_link  FROM `wp_autogenerate_key` where autogenerate_key='$keyck'");
            if ($chek[0]->mail_check_link == 'checked') {

                $menu_links = array_slice($menu_links, 0, 1, true)
                 + array('downloads-sfx' => 'Download')
                 + array_slice($menu_links, 1, null, true);
            }
        }
        return $menu_links;
    } else {
        return $menu_links;
    }

}
/*
 * Step 2. Register Permalink Endpoint
 */
add_action('init', 'add_endpoint');
function add_endpoint()
{

    // WP_Rewrite is my Achilles' heel, so please do not ask me for detailed explanation
    add_rewrite_endpoint('upgrade-subscription', EP_PAGES);
    add_rewrite_endpoint('downloads-sfx', EP_PAGES);

}
/*
 * Step 3. Content for the new page in My Account, woocommerce_account_{ENDPOINT NAME}_endpoint
 */
add_action('woocommerce_account_downloads-sfx_endpoint', 'my_account_endpoint_zip');
function my_account_endpoint_zip()
{
    global $wpdb;
    $download_lnk = $wpdb->get_results("SELECT autogenerate_key  FROM `wp_autogenerate_key` ");
// print_r($download_lnk);
    $download_lnk[0]->autogenerate_key;
    foreach ($download_lnk as $dbld) {
        $dwnlk[] = $dbld->autogenerate_key;
    }
    $currentiduser = get_current_user_id();
    $keyck = get_user_meta($currentiduser, 'activation_key', true);
    if (in_array($keyck, $dwnlk)) {
        // echo "enters";
        $chek = $wpdb->get_results("SELECT mail_check_link,mail_link  FROM `wp_autogenerate_key` where autogenerate_key='$keyck'");
        if ($chek[0]->mail_check_link == 'checked') {
            $downloadedlink = $chek[0]->mail_link;
            ?>
 <button class="woocommerce-Button button" style='text-align:center;margin-top:20%;margin-left:40%;background-color:#ff9933 !important;color:white;border-radius:25px;  ' onclick="window.location.href='<?php echo $downloadedlink; ?>'">DOWNLOAD SFX PACK</button>
<?php
} else {
            $ssk = site_url();
            header("Location:" . $ssk . "/my-account/");
            // echo "<p>Not available.</p>";
            // echo "else";
            ?>
 <!-- <button class="woocommerce-Button button" style='text-align:center;margin-top:20%;margin-left:40%;background-color:#ff9933 !important;color:white;border-radius:25px;  ' onclick="window.location.href='/speed/wp-content/uploads/student_zipfile/nmc-fullsail.zip'">DOWNLOAD SFX PACK</button> -->
    <?php
}
    } else {

        // echo "final";
        ?>
<!-- <button class="woocommerce-Button button" style='text-align:center;margin-top:20%;margin-left:40%;background-color:#ff9933 !important;color:white;border-radius:25px;  ' onclick="window.location.href='/speed/wp-content/uploads/student_zipfile/nmc-fullsail.zip'">DOWNLOAD SFX PACK</button> -->
  <?php
$ssk = site_url();
        header("Location:" . $ssk . "/my-account/");
        // echo "<p>Not available.</p>";
    }
    ?>

 <?php

    // echo  "<form method='post' action=''><button name='get_zip' style='text-align:center;margin-top:20%;margin-left:40%;'>DOWNLOAD SFX PACK</button></form>";
    if (isset($_POST['get_zip'])) {
        //https://nmc-fullsail.s3.amazonaws.com/nmc-fullsail.zip

        $site_url = site_url();
        // exit();
        //$file="https://chopshopfx.com/speed/wp-content/uploads/2020/05/testfiles.zip";
        //$file="https://chopshopfx.com/speed/wp-content/uploads/student_zipfile/wp-content.zip";
        // header("Expires: 0");
        // header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        // header("Cache-Control: private",false);
        // header('Content-disposition: attachment; filename=Fullsail.zip');
        // header("Content-Transfer-Encoding:  binary");
        // header("Content-Length: ".filesize($file));
        // readfile($file);
        ?>
    <!-- <button onlcick="window.location.href='https://nmc-fullsail.s3.amazonaws.com/nmc-fullsail.zip' download">dowload</button> -->
    <!-- <button class="read_more" onclick="window.location.href='/speed/wp-content/uploads/student_zipfile/nmc-fullsail.zip'"> Dowload</button> -->
    <?php

// }
    }
}

add_action('woocommerce_account_upgrade-subscription_endpoint', 'my_account_endpoint_content');
function my_account_endpoint_content()
{
    echo "<div style='text-align:center;margin-top:5%'>";
    $user_idis = get_current_user_id();
    global $wpdb;
    $paid_users = $wpdb->get_results("SELECT * FROM `wp_payment_meta` where payment_status='Completed' and user_id=$user_idis");
    $payment_status = $paid_users[0]->payment_status;

//  $getstd = get_user_meta($user_idis, 'wp_capabilities', true);
//  $newArray = array_keys($getstd);
//  $student_role = $newArray[0];
//  if ($student_role == 'student') {
//     echo "you are in the student role";
//  }
    if ($payment_status == 'Completed') {
        echo "<div class='upgraded_subscription'><b>YOU ALREADY UPGRADED YOUR SUBSCRIPTION!!</b></div>";
    } else {
        if (!current_user_can('update_core')) {

            echo "<h4>Upgrade to a Professional License for 50% Off!</h4>";
            $site_url = site_url();
            echo "<p  style='text-align:left;margin-top:2%;margin-left:13px;margin-right:28px;'>Use the Coupon Code below to upgrade your Student License to a Professional License for 50% OFF the monthly price - forever! By upgrading to a Professional License, you can use the content in any production according to the Professional EULA in the <a href=" . $site_url . '/about-us/' . ">About Us</a> section.</p>";
        }
        $getusers = $wpdb->get_results("Select * FROM `wp_copons_meta` where user_id=$user_idis");
        $exits_user = $getusers[0]->user_id;
        if ($exits_user == $user_idis) {
            $getusers = $wpdb->get_results("Select * FROM `wp_copons_meta` where user_id=$user_idis");
//print_r($getusers);
            echo "<b style='margin-top:20px;margin-bottom:5px;'>Your Coupoun Code is:</b> " . $getusers[0]->coupons_code;
            echo "<br>";
            echo "<br>";
            ?>
<form action="" method="post">
Enter your coupon <input type="text" name="verify_coupons">
<button type="submit" class="woocommerce-Button button" style='background-color:#ff9933 !important;color:white;border-radius:25px;' name="sub_coupon">Submit</button>
</form>
<?php
}

        // echo "<br>";
        // of course you can print dynamic content here, one of the most useful functions here is get_current_user_id()
        // echo '<div class="upgrade-button"><h3>Upgrade Subscription</h3></div>';
        $user_id = get_current_user_id();
        ?>

<?php
if (isset($_POST['sub_coupon'])) {
            $posted_coupon = $_POST['verify_coupons'];
            $verify_coupon = $getusers[0]->coupons_code;
            if ($posted_coupon == $verify_coupon) {
                ?>
    <p style="color:#ff9933">Coupon Applied Successfully</p>
    <h4>PROFESSIONAL LICENSE </h4>
    <div style="display:inline-block;padding-left: 0px;"><h4>$9.99 per Month</h4>
    <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="VK4U56A7NZS4L">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
</div>
<div style="display:inline-block;padding-left: 8%;"><h4> $95.80 per Year</h4>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="RNLS9FSBY97ZY">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>

</div>
<?php
} else {
                echo "<b style='color:red;'>Sorry! Coupon Not Matched!! Please Enter the valid Code!</b>";
                if (!current_user_can('update_core')) {
                    ?>
     <h4>PROFESSIONAL LICENSE </h4>
     <div style="display:inline-block;padding-left: 0px;"><h4>$19.98 per Month</h4>
     <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="JRF4FWM6H8QHE">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
</div>
<div style="display:inline-block;padding-left: 8%;"><h4> $239.76 per Year</h4>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="FLUL4PBC57LE4">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
</div>
    <?php
}
            }
        } else {
            if (!current_user_can('update_core')) {
                ?>
     <h4>PROFESSIONAL LICENSE </h4>
     <div style="display:inline-block;padding-left: 0px;"><h4>$19.98 per Month</h4>
     <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="JRF4FWM6H8QHE">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
</div>
<div style="display:inline-block;padding-left: 8%;"><h4> $239.76 per Year</h4>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="FLUL4PBC57LE4">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
</div>
<?php }
        }
        echo "</div>";?>

 <?php
}
}
// remove the additional tabs in accounts page
add_filter('woocommerce_account_menu_items', 'remove_my_account_links');
function remove_my_account_links($menu_links)
{
    //if (!current_user_can('update_core')) {
    unset($menu_links['edit-address']); // Addresses
    unset($menu_links['orders']); // Remove Orders
    unset($menu_links['downloads']); // Disable Downloads
    unset($menu_links['dashboard']); // Remove Dashboard
    unset($menu_links['upgrade-subscription']);
    //}

    return $menu_links;
}

//to support html support in wordpress mail
function wpse27856_set_content_type()
{
    return "text/html";
}
add_filter('wp_mail_content_type', 'wpse27856_set_content_type');

//recaptcha code

function no_captcha_recaptcha_menu()
{
    add_menu_page("reCapatcha Options", "reCaptcha Options", "manage_options", "recaptcha-options", "recaptcha_options_page", "dashicons-admin-network", 100);
}

function recaptcha_options_page()
{?>
  <div class="wrap">
  <h1>reCaptcha Options</h1>
  <form method="post" action="options.php">
  <?php settings_fields("header_section");
    do_settings_sections("recaptcha-options");
    submit_button();?>
  </form>
  </div>
  <?php }
add_action("admin_menu", "no_captcha_recaptcha_menu");

function display_recaptcha_options()
{
    add_settings_section("header_section", "Keys", "display_recaptcha_content", "recaptcha-options");

    add_settings_field("captcha_site_key", __("Site Key"), "display_captcha_site_key_element", "recaptcha-options", "header_section");
    add_settings_field("captcha_secret_key", __("Secret Key"), "display_captcha_secret_key_element", "recaptcha-options", "header_section");

    register_setting("header_section", "captcha_site_key");
    register_setting("header_section", "captcha_secret_key");
}

function display_recaptcha_content()
{
    echo __('<p>You need to <a href="https://www.google.com/recaptcha/admin" rel="external">register you domain</a> and get keys to make this plugin work.</p>');
    echo __("Enter the key details below");
}

function display_captcha_site_key_element()
{?>
  <input type="text" name="captcha_site_key" id="captcha_site_key" value="<?php echo get_option('captcha_site_key'); ?>" />
  <?php }

function display_captcha_secret_key_element()
{?>
  <input type="text" name="captcha_secret_key" id="captcha_secret_key" value="<?php echo get_option('captcha_secret_key'); ?>" />
  <?php }
add_action("admin_init", "display_recaptcha_options");

function login_recaptcha_script()
{
    if (!is_page(2867)) {
        wp_register_script("recaptcha_login", "https://www.google.com/recaptcha/api.js");
        wp_enqueue_script("recaptcha_login");
    }
}
add_action("login_enqueue_scripts", "login_recaptcha_script");
add_action("wp_enqueue_scripts", "login_recaptcha_script");
function display_login_captcha()
{?>
  <div class="g-recaptcha" data-sitekey="<?php echo get_option('captcha_site_key'); ?>"></div>
  <?php }
add_action("login_form", "display_login_captcha");

function verify_login_captcha($user, $password)
{
    if (isset($_POST['g-recaptcha-response'])) {
        $recaptcha_secret = get_option('captcha_secret_key');
        $response = wp_remote_get("https://www.google.com/recaptcha/api/siteverify?secret=" . $recaptcha_secret . "&response=" . $_POST['g-recaptcha-response']);
        $response = json_decode($response["body"], true);
        if (true == $response["success"]) {
            return $user;
        } else {
            return new WP_Error("Captcha Invalid", __("<strong>ERROR</strong>: You are a bot"));
        }
    } else {
        return new WP_Error("Captcha Invalid", __("<strong>ERROR</strong>: You are a bot. If not then enable JavaScript"));
    }
}
add_filter("wp_authenticate_user", "verify_login_captcha", 10, 2);

function display_comment_recaptcha()
{?>
  <div class="g-recaptcha" data-sitekey="<?php echo get_option('captcha_site_key'); ?>"></div><br/>
  <input name="submit" type="submit" class="submit" value="Post Comment">
  <?php }
add_action("comment_form", "display_comment_recaptcha");

function verify_comment_captcha($commentdata)
{
    if (isset($_POST['g-recaptcha-response'])) {
        $recaptcha_secret = get_option('captcha_secret_key');
        $response = wp_remote_get("https://www.google.com/recaptcha/api/siteverify?secret=" . $recaptcha_secret . "&response=" . $_POST['g-recaptcha-response']);
        $response = json_decode($response["body"], true);
        if (true == $response["success"]) {
            return $commentdata;
        } else {
            echo __("Bots are not allowed to submit comments.");
            return null;
        }
    } else if ((!isset($_POST['g-recaptcha-response'])) && ($_POST['mode'] == 'dashboard')) {
        return $commentdata;
    } else if ((!isset($_POST['g-recaptcha-response'])) && ($_POST['mode'] == 'detail')) {
        return $commentdata;
    } else {
        echo __("Bots are not allowed to submit comments. If you are not a bot then please enable JavaScript in browser.");
        return null;
    }
}
add_filter("preprocess_comment", "verify_comment_captcha");

//woocommerce pages
function wpse_131562_redirect()
{
    if (!is_user_logged_in() && is_shop()) {
        // feel free to customize the following line to suit your needs
        $redirect_url = site_url() . '/my-account/';
        wp_redirect($redirect_url);
        exit;
    } else {
        // return;
    }
}
add_action('template_redirect', 'wpse_131562_redirect');

add_filter('views_users', function ($views) {
    echo "<div style='margin-top:20px'>";
    foreach ($views as $key => $view) {
        if ($key == 'all' || $key == 'administrator' || $key == 'student' || $key == 'commercial') {
            echo "<span style='margin-top:10px;'>" . $view . "&nbsp;&nbsp;|&nbsp;&nbsp;</span>";
        }
    }
    echo "</div>";
});
add_action('admin_head', 'my_custom_fonts');

function my_custom_fonts()
{
    wp_enqueue_style('buddyboss-child-login-css', get_stylesheet_directory_uri() . '/assets/css/login-form.css');
    echo '<style>
  ul.subsubsub {
    display: none;
}

  </style>';
}

add_filter('manage_users_columns', 'rudr_modify_user_table');

function rudr_modify_user_table($columns)
{

    $columns['registration_date'] = 'Registration date';
    $columns['expiry_date'] = 'Expiration date';
    // add new

    return $columns;

}

add_filter('manage_users_custom_column', 'rudr_modify_user_table_row', 10, 3);

function rudr_modify_user_table_row($row_output, $column_id_attr, $user)
{

    $date_format = 'j M, Y H:i';

    switch ($column_id_attr) {
        case 'registration_date':
            return date($date_format, strtotime(get_the_author_meta('registered', $user)));
            break;
        case 'expiry_date':
            $dbdate = get_user_meta($user, 'course_duration', true);
            $arr = explode('/', $dbdate);
            $date_form = $arr[0] . '-' . $arr[1] . '-' . $arr[2];
            $date = date_create($date_form);
            date_add($date, date_interval_create_from_date_string("30 days"));
            $date_for = date_format($date, "j-F-Y");
            return $date_for;
            break;
        default:
    }

    return $row_output;

}

add_filter('manage_users_sortable_columns', 'rudr_make_registered_column_sortable');

function rudr_make_registered_column_sortable($columns)
{

    $columns = wp_parse_args(array('registration_date' => 'registered', 'expiry_date' => 'course_duration'), $columns);
    return $columns;
}

function prefix_sort_by_level($query)
{
    if ('course_duration' == $query->get('orderby')) {
        $query->set('orderby', 'meta_value');
        $query->set('meta_key', 'course_duration');
    }
}
add_action('pre_get_users', 'prefix_sort_by_level');

/* Login redirection */

// function admin_default_page() {
//   $site_url=site_url();
//   if(is_admin())
//   {
//     return $site_url.'/wp-admin';
//   }
//   else{
//     return $site_url.'/wp-admin';

//   }

// }

// add_filter('login_redirect', 'admin_default_page');

/* additional profile clinical information  */
/* 30th may 2020 */

//         if(isset($_POST['field_60']))
//         {
// global $wpdb;
// $value=stripslashes(trim($_POST['field_60']));
// $email=stripslashes(trim($_POST['signup_email_confirm']));
//     $email = explode('@', $email);
//     if (isset($email[1]) && $email[1]) {
//     $domain = $email[1];

//     $result=$wpdb->get_results("SELECT * from wp_autogenerate_key where autogenerate_key='$value' and domain_name='$domain' ");
//     print_r($result);
//     if($result[0]->autogenerate_key==$value && $result[0]->domain_name==$domain)
//     {
//       echo "success";
//     }
//     else
//     {
//       echo "false";
//     }

//     exit;
//         $regex = get_option('rkb_bb_email_regex');
//         if ($regex) {
//       $regex = preg_split('/[\,\;]/', $regex);
//       // echo $domain;
//       if(in_array($domain, $regex))
//       {
//         echo $domain;
//         exit;
//       }

//     }
//   }
// }

// $result=get_results("SELECT * from wp_autogenerate_key where auto_generate_key=$value and ");
//           echo $_POST['field_60'];
//           return false;

add_action('bp_signup_validate', 'rkb_chopshop_buddyboss_signup_validates');

function rkb_chopshop_buddyboss_signup_validates()
{
    if (isset($_POST['field_60'])) {
        $value = stripslashes(trim($_POST['field_60']));
        $email = stripslashes(trim($_POST['signup_email_confirm']));
        $email = explode('@', $email);
        if (isset($email[1]) && $email[1]) {
            $domain = $email[1];
            global $wpdb;
            $result = $wpdb->get_results("SELECT * from wp_autogenerate_key where autogenerate_key='$value' AND  domain_name LIKE '%$domain%' or autogenerate_key='$value' and domain_name=''");

            if ($result[0]->autogenerate_key == $value && $result[0]->domain_name == $domain) {
                return true;
            } else if ($result[0]->autogenerate_key == $value && $result[0]->domain_name == '') {
                return true;
            } else {
                $bp = buddypress();
                $bp->signup->errors['field_60'] = sprintf(esc_html__('Sorry, the activation code  %1$s is incorrect.', 'buddyboss'), $value);
                return false;
            }
        }
    }

}

// global $wpdb;
// $results=$wpdb->get_results("SELECT meta FROM wp_signups order by registered desc limit 1  ");
// //print_r($results);
// $results[0]->meta;
// $test = unserialize($results[0]->meta);
// echo "<pre>";
// print_r($test);
// echo "</pre>";
// exit;
// function century_chopshopfx_bp_inits(){
//     add_action('bp_core_activated_user', 'century_chopshopfx_bp_after_actives', 11, 3);
// }
// add_action('init', 'century_chopshopfx_bp_inits');

// function century_chopshopfx_bp_after_actives($user_id, $key, $user){

//     $userdata = get_userdata($user['user_id']);
//   $user_email = $userdata->user_email;
//   $meta_key='degree_length';
//   foreach($user['meta'] as $meta_key=>$meta_value){
// if($meta_key=='field_39')
// {
//   $meta_key='degree_length';
//   add_user_meta($user_id,$meta_key,$meta_value);
// }
// if($meta_key=='field_38')
// {
// $meta_key='course_duration';
// $meta_values=date_create($meta_value);
// $meta_value=date_format($meta_values,"Y/m/d");
// add_user_meta($user_id,$meta_key,$meta_value);

// }
// // if($meta_key=='field_61')
// // {
// //   $meta_key='secondary_email';
// //   add_user_meta($user_id,$meta_key,$meta_value);
// // }
//   }

//   function generateRandomString($length = 8)
//   {
//       $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
//       $charactersLength = strlen($characters);
//       $randomString = '';
//       for ($i = 0; $i < $length; $i++) {
//           $randomString .= $characters[rand(0, $charactersLength - 1)];
//       }
//       return $randomString;
//   }
//     $couponcode = generateRandomString();
// global $wpdb;
//             $wpdb->insert('wp_copons_meta', array(
//               'user_id' => $user_id,
//               'coupons_code' => $couponcode,
//           ));
//   $subject = 'Welcome to Chop Shop FX';
//   $siteurl=site_url().'/my-account/';
//   //echo $siteurl;
//   $first_name=get_user_meta($user_id,'first_name',true);
// $message_content="Dear " . $first_name.',' . "<br/><br/>
// Your account has been registered at Chop Shop FX.<br/><br/>
// Here is a link for a collection of 5,000 sound effects from Chop Shop FX to use during your program. Just <a href='https://chopshopfx.com/speed/my-account/downloads-sfx/'>click this link</a> to download the collection and read the included Student License Agreement for Terms Of Use. Note, there is an additional 16,000+ sound effects that you can search and download from ChopShopFX.com.
// <br/><br/>
// Make some noise!<br/>
// Chop Shop FX Team";
// //$attachments = array( WP_CONTENT_DIR . '/uploads/test.zip' );
//   $headers = 'From: Chopshopfx <ric@ricviers.com>' . "\r\n";
// // // wp_mail( $to, $subject, $message, $headers, $attachments );
// wp_mail($user_email, $subject, $message_content, $headers);

// }

add_action('woocommerce_edit_account_form', 'add_favorite_color_to_edit_account_form');
function add_favorite_color_to_edit_account_form()
{
    $user = get_current_user_id();
    ?>
        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
        <label for="favorite_color"><?php _e('Secondary Email', 'woocommerce');?></label>
<?php $secondary_email = get_user_meta($user, 'secondary_email', true);?>
        <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" placeholder="secondary email" name="secondary_email" id="favorite_color" value="<?php echo $secondary_email; ?>" />
    </p>
    <?php
}

// Save the custom field 'favorite_color'
add_action('woocommerce_save_account_details', 'save_favorite_color_account_details', 12, 1);
function save_favorite_color_account_details($user_id)
{
    // For Favorite color
    if (isset($_POST['secondary_email']))

    // add_user_meta() {
    update_user_meta($user_id, 'secondary_email', sanitize_text_field($_POST['secondary_email']));
}

// For Billing email (added related to your comment)
// if( isset( $_POST['account_email'] ) )
//     update_user_meta( $user_id, 'billing_email', sanitize_text_field( $_POST['account_email'] ) );
// }

// add_action('bp_signup_validate', 'rkb_chopshop_buddyboss_signup_validates_two');
// function rkb_chopshop_buddyboss_signup_validates_two()
// {
//   if(isset( $_POST['field_60']))
//   {
//     $value=stripslashes(trim($_POST['field_60']));
//     $email=stripslashes(trim($_POST['signup_email_confirm']));
//       $email = explode('@', $email);
//     if(isset($email[1]) && $email[1]) {
//     $domain = $email[1];
//     global $wpdb;
//     $result=$wpdb->get_results("SELECT * from wp_autogenerate_key where autogenerate_key='$value' AND  domain_name='$domain' or autogenerate_key='$value' and domain_name=''");

//     if($result[0]->autogenerate_key==$value && $result[0]->domain_name==$domain)
//     {
//      return true;
//     }
//     else if($result[0]->autogenerate_key==$value && $result[0]->domain_name=='')
//     {
//       return true;
//     }
//     else
//     {
//       $bp = buddypress();
//       $bp->signup->errors['field_60'] = sprintf(esc_html__('Sorry, the activation code  %1$s is incorrect.', 'buddyboss'), $value);
//      return false;
//     }
//   }
// }

// }

    add_action('wp_ajax_contact_form', 'contact_form');
    add_action('wp_ajax_nopriv_contact_form', 'contact_form');

    function contact_form()
{
        $insertvalue = '';
        $name = $_POST['activation_key'];
        $username = stripslashes(trim($_POST["last_name"]) . ' ' . trim($_POST["first_name"])); 
        // $username = stripslashes(trim($_POST['user_name']));
        $value = stripslashes(trim($_POST['activation_key']));
        $password = stripslashes(trim($_POST['password']));
        $first_name = stripslashes(trim($_POST['first_name']));
        $last_name = stripslashes(trim($_POST['last_name']));
        $email = stripslashes(trim($_POST['email']));

        function generateRandomString($length = 8)
    {
            $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';
            for ($i = 0; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
            }
            return $randomString;
        }
        // if (null == email_exists($email)) {
            // if (null == username_exists($username)) {
                if (isset($_POST['activation_key'])) {
                    global $wpdb;
                    $value = stripslashes(trim($_POST['activation_key']));
                    $key_exist_check = $wpdb->get_results("SELECT * from `wp_usermeta` where meta_key='activation_key' and meta_value='$value'");
                    // print_r($key_exist_check);
                    foreach ($key_exist_check as $keyexist) {
                        //print_r($keyexist);
                        $keyexistah[] = $keyexist->meta_value;
                    }
                    if ($value != $keyexistah[0]) {
                        // echo "enter into the condition";
                        $email = stripslashes(trim($_POST['email']));
                        $emaildomain = explode('@', $email);
                        if (isset($emaildomain[1])) {
                            $domain = $emaildomain[1];
                            global $wpdb;
                            $result = $wpdb->get_results("SELECT * from wp_autogenerate_key where autogenerate_key='$value' AND  domain_name LIKE '%$domain%' or autogenerate_key='$value' and domain_name=''");
                            // print_r($result[0]->domain_name);
                            // $emdmin = explode("", $result[0]->domain_name);
                            $multiple_domain = explode(",", $result[0]->domain_name);
                            foreach ($multiple_domain as $msd) {
                                $msdon[] = $msd;
                            }

                            $showmsg = $wpdb->get_results("SELECT mail_check_link,mail_link  FROM `wp_autogenerate_key` where autogenerate_key='$value'");
                            if (in_array($domain, $msdon)) {
                                if (($result[0]->autogenerate_key == $value) && ($result[0]->autogenerate_key == $value && $result[0]->domain_name == '')) {
                                    $insertvalue = '0';
                                }

                            } else if (($result[0]->domain_name == $email || $result[0]->autogenerate_key == $value) && $showmsg[0]->mail_check_link == 'checked') {
                                // echo "successok";
                                $insertvalue = '4';
								if ($insertvalue == '4') {

									$fullname = $last_name . $first_name;
									$user_id = wp_create_user($fullname, $password, $fullname);
									// echo "user_id is-";
									// print_r($user_id);
									// die;
									if ($user_id != 1) {
										wp_update_user(
											array(
												'ID' => $user_id,
												'nickname' => $fullname,
											)
										);
									}
									$user = new WP_User($user_id);
									$user->set_role('student');
									$degree_length = $result[0]->course_duration;
									$current_date = date("Y/m/d");
									$date = date_create($current_date);
									$st = $degree_length . ' months';
									date_add($date, date_interval_create_from_date_string($st));
									$course_durations = date_format($date, 'Y/m/d');
									$get_meta = array('degree_length' => $degree_length, 'course_duration' => $course_durations, 'activation_key' => $value);
									foreach ($get_meta as $meta_key => $meta_value) {
										add_user_meta($user_id, $meta_key, $meta_value, $unique = false);
									}
									if ($user_id != 1) {
										$user_data = wp_update_user(array('ID' => $user_id, 'user_email' => $email, 'display_name' => $first_name));
										update_user_meta($user_id, 'first_name', $first_name);
										update_user_meta($user_id, 'last_name', $last_name);
									}
									$to = $email;
									$subject = 'Welcome to Chop Shop FX';
									$siteurl = site_url() . '/my-account/';
									$message_content = "Dear " . $first_name . ',' . "<br/><br/>Your account has been registered at Chop Shop FX.<br/><br/>Here is a link for a collection of 5,000 sound effects from Chop Shop FX to use during your program. Just <a href='https://chopshopfx.com/my-account/downloads-sfx/'>click this link</a> to download the collection and read the included Student License Agreement for Terms Of Use. Note, there is an additional 16,000+ sound effects that you can search and download from ChopShopFX.com.<br/><br/>Make some noise!<br/>Chop Shop FX Team";
	
									$headers = 'From: Chop Shop FX <help@chopshopfx.com>' . "\r\n";
	
									$vary_user = $wpdb->get_results("SELECT mail_check_link from `wp_autogenerate_key` where autogenerate_key='$value' ");
									$vary_user[0]->mail_check_link;
									if ($vary_user[0]->mail_check_link == 'checked') {
										$success_mail = wp_mail($to, $subject, $message_content, $headers);
									}
	
									$couponcode = generateRandomString();
									$getuserscoupon = $wpdb->get_results("SELECT coupons_code FROM `wp_copons_meta`");
									foreach ($getuserscoupon as $existing_coupon) {
										$existing_coupos[] = $existing_coupon->coupons_code;
									}
									if (in_array($couponcode, $existing_coupos)) {
										// echo "duplicate coupon";
										$name = (rand(10, 1000));
										$couponcode = $couponcode . $name;
									} else {
										$couponcode;
									}
									$wpdb->insert('wp_copons_meta', array(
										'user_id' => $user_id,
										'coupons_code' => $couponcode,
									));
									global $wpdb;
									$showmsg = $wpdb->get_results("SELECT mail_check_link,mail_link  FROM `wp_autogenerate_key` where autogenerate_key='$value'");
									if ($showmsg[0]->mail_check_link == 'checked') {
										echo "successok";
										exit;
									} else {
										echo "success";
	
									}
									exit;
								}
                                // exit;
                            } else if ($result[0]->domain_name == "" && $result[0]->autogenerate_key == $value) {
                                if ($result[0]->autogenerate_key == $value) {
                                    $insertvalue = '4';
                                } else if ($result[0]->autogenerate_key == $value && $result[0]->domain_name == '') {
                                    $insertvalue = '4';
                                } else {
                                    echo "3";
                                    die;
                                }

                            } else {
                                echo "3";
                                die;
                            }

                           
                        }
                    } else {
                        echo "7"; //activation key exist;
                        die;
                    }
                } else {
                    echo "2";
                    die;
                }
            // } //user exits end
            // else {
            //     echo "1";
            //     die;
            // }
        // } //email exists end
        // else {
        //     echo "0email_exists";
        //     die;
        // }
    }
/* login redirect for admin */

    function wpdocs_my_login_redirect($url, $request, $user)
{
        if ($user && is_object($user) && is_a($user, 'WP_User')) {
            if ($user->has_cap('administrator')) {
                $url = admin_url();
                $uri = $_SERVER['REQUEST_URI'];
                $serverurl = $_SERVER['HTTP_REFERER'];
                if (site_url() . '/letmein/?loggedout=true&wp_lang=en_US' == $serverurl) {
                    header("location:" . site_url() . "/wp-admin/");
                    exit;
                    $url = admin_url();
                }
            } else {
                header("location:" . site_url() . "/my-account/");
                exit;
            }
        }
        return $url;
    }
    add_filter('login_redirect', 'wpdocs_my_login_redirect', 10, 3);

    function yourfunction()
{
        global $wpdb;
        $id = get_current_user_id();
        $getstd = get_user_meta($id, 'wp_capabilities', true);
        $newArray = array_keys($getstd);
        $arr = [];
        $date_form = get_user_meta($id, 'course_duration', true);
        $arr = explode('/', $date_form);
        $date_form = $arr[0] . '-' . $arr[1] . '-' . $arr[2];
        $date = date_create($date_form);
        date_add($date, date_interval_create_from_date_string("30 days"));
        $then = str_replace("/", "-", $date_form);
        $then = strtotime($then);
        $dbdate;
        $now = time();
        $difference = $then - $now;
        $days = floor($difference / (60 * 60 * 24));
        if ($newArray[0] == 'student' || $newArray[1] == 'student') {

            if ($days < -31) {
                $payment_checking = $wpdb->get_results("Select * FROM `wp_payment_meta` where user_id=$id and payment_status='Completed'");
                $user_id = $payment_checking[0]->user_id;
                $pay_check = $payment_checking[0]->payment_status;
                if ($pay_check == 'Completed' && $user_id == $id) {
                    $wpdb->query($wpdb->prepare("UPDATE wp_users  SET user_status=0 WHERE ID=$id"));
                } else {
                    $wpdb->query($wpdb->prepare("UPDATE wp_users  SET user_status=1 WHERE ID=$id"));
                }
            }
        }
    }

//add_action('init', "yourfunction");

//logout redirect

    add_action('wp_logout', 'auto_redirect_external_after_logout');
    function auto_redirect_external_after_logout()
{
        $surl = site_url();
        wp_redirect($surl);
        exit();
    }