/* This is your custom Javascript */
jQuery(document).ready(function($){

    let toggleButtonClass = ($elem) => {
        if($elem.hasClass('bb-icon-play-circle')){
            $elem.removeClass('bb-icon-play-circle').addClass('bb-icon-pause-circle');
        }else{
            $elem.removeClass('bb-icon-pause-circle').addClass('bb-icon-play-circle');
        }
    };

    $(document.body).on('click', '.wavesurfer-audio .play-button', function(e){
        e.preventDefault();
        var parent = $(this).closest('.wavesurfer-block');
        parent.find('.wavesurfer-buttons_set .wavesurfer-play').trigger('click');
        toggleButtonClass($(this));
    });

    $('.wavesurfer-audio .wavesurfer-play').each(function(){
        var targetNode = this;
        var callback = (mutationsList, observer) => {
            
            for(let mutation of mutationsList) {
                if (mutation.type === 'attributes' && mutation.attributeName == 'class') {
                    var $elem = $(targetNode).closest('.wavesurfer-audio').find('a.play-button');
                    if($(targetNode).hasClass('wavesurfer-active-button')){
                        $elem.removeClass('bb-icon-play-circle').addClass('bb-icon-pause-circle');
                    }else{
                        $elem.removeClass('bb-icon-pause-circle').addClass('bb-icon-play-circle');
                    }
                }
            }
        };

        var config = { attributes: true, childList: false, subtree: false };
        
        var observer = new MutationObserver(callback);

        observer.observe(targetNode, config);
    });
});