// console.log("file coming");
jQuery(document).ready(function () {
	jQuery('.strongone').hide();
	jQuery('.mediumone').hide();
	jQuery('.weakone').hide();
	jQuery('.veryweakone').hide();
	// jQuery(".successmsg").hide();
	jQuery("#password").keyup(function(){
		password=jQuery("#password").val();
		var patt1 = /[A-Za-z-!@#$%^&*()+=]/g;
		var patt2=/[0-9]/g;
		var patt3=/[A-Z]/g;
		email = jQuery("#emailid").val();
		confirm_email=jQuery("#confirm_emailid").val();
		var pattern2 = password.match(patt2);
		if(email!=confirm_email)
		{
			jQuery('.showmismatch').show();

		}
		else 
		{
			jQuery('.showmismatch').hide();
	
		}
		if(password.length<5)
		{
			jQuery('.veryweakone').show();
		}
		else 
		{
			jQuery('.veryweakone').hide();
		}
		if(password.length>=5&&!(pattern2))
		{
			// jQuery('.weakone').show();	
			jQuery('.strongone').show();
		}
		else 
		{
			jQuery('.weakone').hide();
		}
		if(password.length>=6&&!(patt3)&& password.length<10)
		{
			jQuery('.mediumone').show();	
		}
		else 
		{
			jQuery('.mediumone').hide();
		}
		// if(password.length>=10 &&  password.match(patt1) && password.match(patt2) )
		if(password.length>=9 )
		{
			jQuery('.strongone').show();	
		}
		else 
		{
			jQuery('.strongone').hide();
		}
	});
	jQuery("#signup_submit_2").click(function(){
		var email,confirm_email,password,confirm_password,first_name,last_name,user_name,activation_key;	
		email = jQuery("#emailid").val();
		confirm_email=jQuery("#confirm_emailid").val();
		password=jQuery("#password").val();
		confirm_password=jQuery("#confirm_password").val();
		first_name=jQuery("#first_name").val();
		last_name=jQuery("#last_name").val();
		user_name=jQuery("#user_name").val();
		activation_key=jQuery("#activation_key").val();
		jQuery(".emailerr").hide();
		// jQuery(".successmsg").hide();
		jQuery(".successmsgtwo").hide();
		jQuery(".loginmessage").hide();
		jQuery(".loginmessagetwo").hide();
		jQuery(".passerr").hide();
		jQuery(".passerr").hide();
		jQuery(".fnameerr").hide();
		jQuery(".lnameerr").hide();
		jQuery(".unamekey_err").hide();	
		jQuery(".activation_keyerr").hide();
		jQuery('.showmismatch').hide();
		jQuery('.showmismatchemail').hide();

		if(email==""||password==""||first_name==""||last_name==""||user_name==""||activation_key=="")
		{
		if(email=="")
		{
			jQuery(".emailerr").show();
		}
		else
		{
			jQuery(".emailerr").hide();
		}
		if(password=="")
		{
			jQuery(".passerr").show();
		}
		else{
			jQuery(".passerr").hide();
		}
		if(first_name=="")
		{
			jQuery(".fnameerr").show();
		}
		else 
		{
			jQuery(".fnameerr").hide();
		}
		if(last_name=="")
		{
			jQuery(".lnameerr").show();
		}
		else 
		{
			jQuery(".lnameerr").hide();
		}
		if(user_name=="")
		{
			jQuery(".unamekey_err").show();
		}
		else
		{
			jQuery(".unamekey_err").hide();	
		}
		if(activation_key=="")
		{
			jQuery(".activation_keyerr").show();
		}
		else 
		{
			jQuery(".activation_keyerr").hide();
		}

		return false;
	}
	if(email!=confirm_email)
	{
		jQuery('.showmismatchemail').show();
		return false;
	
	}
	else
	{
		jQuery('.showmismatchemail').hide();
	}
	 if(password!=confirm_password){
		jQuery('.showmismatch').show();
		return false;
	}
	else 
	{
		jQuery('.showmismatch').hide();
	}
	jQuery("#loaderIcon_two").show();
var ajaxurl = "/wp-admin/admin-ajax.php";
jQuery.ajax({ 
	
data:{action:'contact_form',email:email,confirm_email:confirm_email,password:password,confirm_password:confirm_password,first_name:first_name,last_name:last_name,user_name:user_name,activation_key:activation_key},
type:'post',
url:ajaxurl,
success:function(data)
{	
if(data=='0')
{
	jQuery("#loaderIcon_two").hide(1000);
	jQuery(".successmsg").html("Email id already exists").css({"background-color":"#ef3e46","color":"white","border-radius":"3px","padding":" 6px 12px","display":"block"});
	return false;
}
else if(data=='1')
{
	jQuery("#loaderIcon_two").hide(1000);
	jQuery(".successmsg").html("Username already exists").css({"background-color":"#ef3e46","color":"white","border-radius":"3px","padding":" 6px 12px"});
	return false;
}
else if(data=='2'||data=='3')
{
	jQuery("#loaderIcon_two").hide(1000);
	jQuery(".successmsg").html("Activation key is incorrect").css({"background-color":"#ef3e46","color":"white","border-radius":"3px","padding":" 6px 12px"});
	return false;
}
else if(data=='7')	
{
	jQuery("#loaderIcon_two").hide(1000);
	jQuery(".successmsg").html("Activation key already exists!").css({"background-color":"#ef3e46","color":"white","border-radius":"3px","padding":" 6px 12px"});
	return false;
}
else 
{ 
	console.log(data);
jQuery("#loaderIcon_two").hide(1000);  
jQuery(".successmsgtwo").show();
jQuery(".successmsg").hide();
if(data=='successok')
{
	jQuery(".loginmessage").show();
}
else{
	jQuery(".loginmessage").hide();
}
jQuery(".loginmessagetwo").show();
jQuery('#emailid').val("");
jQuery('#confirm_emailid').val("");
jQuery('#password').val("");
jQuery('#confirm_password').val("");
jQuery('#first_name').val("");
jQuery('#last_name').val("");
jQuery('#user_name').val("");
jQuery('#activation_key').val("");
}
}
});
return false;	 
});
});