paypal.Buttons({ 
    style: { 
        shape: 'pill', color: 'black', layout: 'vertical', label: 'subscribe',
         }, 
createSubscription: function(data, actions) {
     return actions.subscription.create({ 'plan_id': 'P-585679819L6262058L244NDQ' });
      }, onApprove: function(data, actions) { 
          alert(data.subscriptionID); } 
          }).render('#paypal-button-container');
