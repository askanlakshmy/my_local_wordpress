<?php 
/* Template Name: Upgrade Subscription */

get_header();

global $wpdb;

if(isset($_POST['couponcode']))
{
   //echo $_POST['couponcode'];
    function generateRandomString($length = 8) {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
    $user_idis= get_current_user_id();
    $getusers= $wpdb->get_results("Select * FROM `wp_copons_meta` where user_id= $user_idis");
   $user_idis= get_current_user_id();
    $couponcode=generateRandomString();
    //echo  $couponcode;
$exits_user= $getusers[0]->user_id;
if($exits_user==$user_idis)
{
  echo "";
  //echo "your coupon code is:".$getusers[0]->coupons_code;
}
else
{
   // echo "you don't have the coupoun code";
    $wpdb->insert('wp_copons_meta', array(
        'user_id' =>  $user_idis,
        'coupons_code' => $couponcode,
    ));
}



?>

<form method="post"  id="commercialsubscription" action="/speed/commercialsubscriptions/">
 <input type="submit" name="submit_user" value="Commercial Subscription ($19.98 a month)" id="submit_user">
 </form>
 <br>
 <form method="post"  id="commercialsubscription" action="/speed/alumnisubscriptions/">
 <input type="submit" name="submit_user" value="Alumni Subscription ($9.9\9 a month)" id="submit_user">
 </form>
 <!-- https://chopshopfx.com/alumnisubscriptions -->

<?php 

}

get_footer();

?>