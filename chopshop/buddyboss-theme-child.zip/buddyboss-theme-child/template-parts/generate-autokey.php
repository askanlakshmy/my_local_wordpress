<?php
/* Template Name: Auto Generate key */
get_header();
?>
<div class="container" style='margin-top:40px;text-align:center;'>
  <div class="row">
    <div class="col-md-6" >
        <form action="" method="post">
            <div class="domain-key">
                  <!-- <span>Associated Domains</span> -->
                  <table>
                  
                  <tr><td class="tdl">Associated Domains</td><td class="tdr"> <textarea class="domain-key-value"  placeholder="Eg..gmail.com" name="domain_key"></textarea></td></tr>
                  <tr><td class="tdl">Batch ID</td><td class="tdr"> <input type="text" placeholder="Batch Id" name="batch_id"></td></tr>
                  <tr><td class="tdl">Course Duration</td><td class="tdr"><input type="number" value="12" name="courseduration" ></td></tr>
                   <tr><td class="tdl">Download Link</td><td class="tdr">
                   <input type="checkbox" id="showCheckoutHistory" value="checked" checked name="mail_checkbox" >
                   <?php $web_url= site_url(); ?>
                  <div id="downlod_link" > <textarea class="domain-key-value"  id="dwnlink" placeholder="Download Link.." name="mail_link"><?php echo $web_url ;?>/wp-content/uploads/student_zipfile/nmc-sfx.zip</textarea> </div>
                   </td></tr>
                  <tr><td class="tdl">Batch Name</td><td class="tdr"><input type="text" placeholder="Batch Name"  name="batch_name" ></td></tr>
                  <tr><td class="tdl">Number of Keys</td><td class="tdr"><input type="number" placeholder="" name="batch_auto_key" ></td></tr>
               
                      <!-- <textarea class="domain-key-value"  placeholder="Eg..gmail.com" name="domain_key"></textarea>
                      </div>
                      <span>Enter Batch ID</span> <input type="text" placeholder="Enter the Batch Id" name="batch_id"><br/><br/>
                      <span>Enter Course Duration</span> <input type="text" placeholder="Course Duration" name="courseduration" ><br/><br/>
                      <span>Enter Batch Name</span> <input type="text" placeholder="Batch Name" name="batch_name" ><br/><br/>
                      <span>Enter Keys to be generated</span> <input type="text" placeholder="Number of keys to be generate" name="batch_id"><br/> <br/> -->

         <tr><td></td> <td class="tdr"> <button type="submit" name="generateakey" class="autogenkey-btn" style='background-color: #ff9933;color:white;border-radius:25px;' >Generate Account Activation Key</button></td></tr>
          </table>
        </form>
    </div>
 </div>
<?php
if (isset($_POST['generateakey'])) {
    $domain_key = trim($_POST['domain_key']);
    // $domain_key = $_POST['dateofcreated'];
    $batch_id = $_POST['batch_id'];
    $courseduration = $_POST['courseduration'];
    $batch_name = $_POST['batch_name'];
    $batch_auto_key = $_POST['batch_auto_key'];
    $mail_checkbox = $_POST['mail_checkbox'];
    $mail_link = trim($_POST['mail_link']);
// print_r($mail_link);
// print_r($mail_checkbox);

    if($mail_checkbox=="")
    {
      $mail_checkbox='no';
    }
// echo "ck=".$mail_checkbox;
//     die;
    // print_r($mail_checkbox);
    // echo "<br>";
    // print_r($mail_link);
    // die;

    function generateRandomString($length = 22)
    {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
    $autogenkey = array("Last Name,First Name,Email,Duration,Activation Key");
    global $wpdb;
    $keyall=$wpdb->get_results("SELECT autogenerate_key FROM wp_autogenerate_key");
      for($b=0;$b<sizeof($keyall);$b++)
    {
        $keyin[]=$keyall[$b]->autogenerate_key; 
    }
    for ($i = 1; $i <= $batch_auto_key; $i++) {
     
            $autogenkey[$i] = $courseduration.",".generateRandomString();
            // $courseduration[$i]

      
    // print_r($autogenkey);
    $site = site_url();

// $file_name= $domain_key.':'.strtotime("now");
$date_format=date("Y-m-d");
 

$file_saving_name=$batch_name."_".str_replace(" ",'',$date_format)."_".$batch_id;
$file_saving_name=str_replace(":","",$file_saving_name);
$file_saving_name=str_replace(" ","",$file_saving_name);
    $paths = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/uploads/2020/05/'.$file_saving_name.'.csv';
    $file_name=str_replace("/home/chopshopfx/public_html/wp-content/uploads/2020/05/",'',$paths);

    if (!(in_array($autogenkey[$i],$keyin)))
    { 
      $keyvalue=explode(",",$autogenkey[$i]);
    }
    else
    {
        $randomtwo=rand(10,1000);
        $autogenkey[$i].$randomtwo;
        
        $keyvalue=explode(",",$autogenkey[$i]);
        
    }
    $wpdb->insert('wp_autogenerate_key',array('autogenerate_key'=>$keyvalue[1],'domain_name'=>$domain_key,'batchname'=>$batch_name,'batchid'=>$batch_id,'course_duration'=>$courseduration,'file_name'=>$file_name,'mail_check_link'=>$mail_checkbox,'mail_link'=>$mail_link),array('%s','%s','%s','%s','%s','%s','%s','%s'));
}
    $fp = fopen($paths, 'w');
    $count=0;
    foreach ($autogenkey as  $line) {
        if(!(in_array($line,$keyin)))
        {

            if($count==0)
            {
                $lines=$line;    
            }
            else
            {
              $lines=",,,".$line;
            }   
        $val = explode(",", $lines);
        fputcsv($fp, $val);
        $count++;
        }
    }
    fclose($fp);
}
    
    ?>
        <div class="row">
              <div class="col-md-6" >

              <!-- <table id="myTable">
 
    <thead>  <tr ><th>Sites</th><th>Sites</th></tr></thead>
    <tbody>
      <tr><td><?php //echo "SitePoint";?></td><td>Flippa</td></tr>
      <tr><td>Learnable</td><td>Learnable</td></tr>
      <tr><td>Flippa</td><td>Flippa</td></tr>
    </tbody>
  </table> -->


                    <table  id="myTable" class='table-styles' style="border:1px solid black;">
                            <thead>  <tr ><th>Batch ID</th><th>Date</th><th>Batch Name</th><th>Duration</th><th style="width:300px !important;">Domain</th><th>Download&nbsp;&nbsp;&nbsp;&nbsp;</th></tr></thead>
                                  <?php
                                  echo "<tbody>";
                               $paths = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/uploads/2020/05/*.csv';
                              
                               $files = glob($paths);
                              //  $i=0;

                            //    usort($files, function($x, $y) {
                            //     return filemtime($x)  filemtime($y);
                            // });
                               foreach($files as $file)
                               {
                               
                                  //  $i++;
                                   $filecreated=$file;
                                   $file=str_replace("/home/chopshopfx/public_html/wp-content/uploads/2020/05/",'',$file);
                                   global $wpdb;
                                   $resutls=$wpdb->get_results("SELECT * FROM `wp_autogenerate_key` WHERE file_name='$file' ");

                                   $csvname=$file;
                                   $file=explode(":",$file);
                                   $dateis=str_replace(".csv",'',$file[1]);
                                  // $datenow=date("Y/d/m ",$dateis); 
                                  $datenow=date("jS-F-Y ",$dateis); 
                                   $site=site_url();
                                   if($file[2]!='19am.csv')
                                   {
                                 if($file[0]=="")
                                 {
                                      $file[0]='Any Domain';
                                 }
                                 if($resutls[0]->domain_name==''){ 
                                   $domain=  "any domain";
                                    }else
                                    { 
                                        $domain=$resutls[0]->domain_name;
                                     }
                                    //  print_r($resutls[0]);
                                    
                                    $datenewfor=date("d/m/Y", filemtime($filecreated));
                    echo "<tr><td>".$resutls[0]->batchid."</td><td><span>$datenewfor</span>" . date("jS-F-Y", filemtime($filecreated)) . "</td><td>". $resutls[0]->batchname."</td><td>".$resutls[0]->course_duration."</td><td>" . $domain . "</td><td><a href='" . $site . "/wp-content/uploads/2020/05/" . $csvname . "'>Download</a></td></tr>";
                                 }
                               } 
                               echo "</tbody>"; 
                              
                  //  echo "<tr><td>&nbsp;&nbsp;&nbsp;1</td><td >" . $domain_key . "</td><td >" . $domain_key . "</td><td><a href='" . $site . "/wp-content/uploads/2020/05/" . $file_name . '.csv' . "'>Download</a></td></tr>";
                    ?>
                </table>
                <?php 
                      //   usort($files, function($x, $y) {
                      //     return filemtime($x) > filemtime($y);
                      // });
                ?>
    <!-- <a href='<?php //echo $site; ?>/wp-content/uploads/2020/05/<?php //echo $csv . '.csv' ?>'><button  class="woocommerce-Button button" style='background-color:#ff9933 !important;color:white;border-radius:25px;'>Click here to download Activation Key</button></a> -->
              </div>
</div>
</div>


 <?php
echo "</div>";
?>



<?php
get_footer();
?>

                             
                        