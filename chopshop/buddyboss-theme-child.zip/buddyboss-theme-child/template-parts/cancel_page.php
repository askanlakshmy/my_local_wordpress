<?php
/* Template Name: Cancel Page */
get_header(); ?>

<div class="jumbotron text-center" style="margin-top:10%">
  <h1 class="display-3">Oh Sorry! It seems like you cancelled your subscription.</h1>
 
  <hr>
  <p>
    Please upgrade your subscription - <a href="https://chopshopfx.com/speed/my-account/upgrade-subscription/">Upgrade</a>
  </p>
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="https://chopshopfx.com/speed/my-account/" role="button">Continue to homepage</a>
  </p>
</div>

<?php get_footer();