<?php
/* Template Name: fullsail registration */
get_header();

if (!(is_user_logged_in())) {
    ?>
<?php $siteurl = site_url();?>
<div id="content" class="site-content new-regform">
<div class="container">
<div class="bb-grid site-content-grid">
<!-- <div class="login-split">
<div style="padding-top: 8%;"></div>
<div class="split-overlay"></div>
</div> -->
<div id="primary" class="content-area bs-bp-container-reg registerform-width-new">
<main id="main" class="site-main">
<div class="register-section-logo">
<a href="<?php echo $siteurl; ?>" rel="home">Chop Shop FX</a>
</div>
<article id="post-0" class="bp_register type-bp_register post-0 page type-page status-publish hentry">
<header class="entry-header entry-header-new-form">

<h1 class="entry-title newentry-title">Create an Account</h1><span class="new-signintitle">or <a href="<?php echo $siteurl; ?>/my-account/">Sign in</a></span>
</header>
<div class="entry-content">
<div id="buddypress" class="buddypress-wrap extended-default-reg">

<div id="register-page" class="page register-page">
<form action="" name="signup_form" id="signup-form" class="standard-form signup-form clearfix" method="post" enctype="multipart/form-data">
<div class="columnone">
<label for="signup_email">Email </label>
<div class="bp-messages bp-feedback error emailerr" style="display:none;">
		<span class="bp-icon" aria-hidden="true"></span>
		<p>Please make sure to enter your email twice.</p>
        </div>
        <div id="pass-strength-result" class="showmismatchemail" style="display:none">Mismatch Email</div>
<input type="email" name="emailid" id="emailid">
<label for="signup_email_confirm">Confirm Email </label>
<input type="email" name="confirmemailid" id="confirm_emailid">
<label for="signup_password">Password </label>
<div class="bp-messages bp-feedback error passerr" style="display:none;">
		<span class="bp-icon" aria-hidden="true"></span>
		<p>Please make sure to enter your password twice.</p>
	</div>
<input type="password" name="password" id="password">
<div id="pass-strength-result" class="veryweakone" style="display:none;background-color:#ef3e46;color:#fff;">Very weak</div>
<div id="pass-strength-result" class="weakone" style="display:none;">weak</div>
<div id="pass-strength-result" class="mediumone" style="display:none;background-color:#e0e1e1;">Medium</div>
<div id="pass-strength-result" class="strongone" style="display:none;color:#fff;background-color:#1cd991;">Strong</div>
<div id="pass-strength-result" class="showmismatch" style="display:none">Mismatch</div>
<label for="signup_password_confirm">Confirm Password </label>
<input type="password" name="confirm_password" id="confirm_password">

</div>
<div class="columntwo">
<legend id="firstname">First Name</legend>
<div class="bp-messages bp-feedback error fnameerr" style="display:none;">
		<span class="bp-icon" aria-hidden="true"></span>
		<p>This is a required field.</p>
	</div>
<input type="text" name="first_name" id="first_name">
<legend id="field_2-1">Last Name</legend>
<div class="bp-messages bp-feedback error lnameerr" style="display:none;">
		<span class="bp-icon" aria-hidden="true"></span>
		<p>This is a required field.</p>
	</div>
<input type="text" name="last_name" id="last_name">
<legend id="field_60-1">Activation key</legend>
<div class="bp-messages bp-feedback error activation_keyerr" style="display:none;">
		<span class="bp-icon" aria-hidden="true"></span>
		<p>This is a required field.</p>
	</div>
<input type="text" name="activation_key" id="activation_key">

<p class="register-privacy-info">
			By creating an account you are agreeing to the <a class="popup-modal-register popup-terms" href="#terms-modal">Terms of Service</a> and <a class="popup-modal-register popup-privacy" href="#privacy-modal">Privacy Policy.</a>		</p>
            <div id="terms-modal" class="mfp-hide registration-popup bb-modal">
<h1>Terms of Service</h1>
        <button title="Close (Esc)" type="button" class="mfp-close">×</button>
</div>
<div id="privacy-modal" class="registration-popup bb-modal mfp-hide">
			<h1>Privacy Policy</h1>
						<button title="Close (Esc)" type="button" class="mfp-close">×</button>
		</div>
<br/>
        <p class="successmsg"></p>
		<p class="successmsgtwo" style="display:none;">Your account has been successfully registered.</p>
		<p class="loginmessage" style="display:none;">Please check your email for a download link to a special collection of 5,000 sound effects.</p>
		<?php $site_url= site_url(); ?>
		<p class="loginmessagetwo" style="display:none;">You can login to your account <a href="<?php echo $site_url; ?>/my-account/">here.</a></p>
<p id="loaderIcon_two" style="display:none;"><img src="<?php echo get_stylesheet_directory_uri() . '/assets/images/ajax-loader.gif' ?>"/></p>
<input type="submit" name="signup_submit_2" id="signup_submit_2" value="Create Account">
</div>
</form>
</div>
</div><!-- #buddypress -->
</div><!-- .entry-content -->
</article>
</main><!-- #main -->
</div><!--  #primary  -->
</div><!-- .bb-grid  -->
</div><!-- .container -->
</div>
<?php
} else {
    $site = site_url();
    // https://chopshopfx.com/speed/my-account/

    header("Location: " . $site . "/my-account/");
}
get_footer();
?>