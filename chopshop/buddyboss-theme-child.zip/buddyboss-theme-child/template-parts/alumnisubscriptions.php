<?php 
/* Template Name: alumnisubscriptions */

get_header();
?> 
<div id="paypal-button-container"></div>
<script src="https://www.paypal.com/sdk/js?client-id=AVkvdnxQKXkEkm3B3WEnyZvzYPg5uipLlY8QteS3yCJkLemZFksg-BP9OoCc6jfRKO3Y8DS_nU2WC0X_&vault=true" data-sdk-integration-source="button-factory"></script>



<?php 

get_footer();
