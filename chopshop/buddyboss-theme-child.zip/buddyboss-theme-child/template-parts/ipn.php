<?php
/* Template Name: Success response */

//print_r($_REQUEST,true);



//if( (strtolower($_REQUEST['payer_status']) == 'unverified' || strtolower($_REQUEST['payer_status']) == 'verified' ) && (strtolower($_REQUEST['txn_type']) == 'subscr_signup' || strtolower($_REQUEST['txn_type']) == 'subscr_payment') ) { 
   // if(isset($_REQUEST['payment_status']) && strtolower($_REQUEST['payment_status']) == 'completed') {
       global $wpdb;
    // mail('vigneswaran.askan@gmail.com','payapal IPN Response using mail finals',print_r($_REQUEST,true));
    if($_REQUEST['subscr_date']!='')
    {
    $payment_date = trim(str_replace('PDT','',$_REQUEST['subscr_date']));
    $payment_date = date('Y-m-d H:i:s',strtotime($payment_date));					
    $start_date = date('Y-m-d',strtotime($payment_date));
    }
    if($_REQUEST['amount3']=="") {   $amount3=$_REQUEST['mc_gross']; }
    else{ $amount3= $_REQUEST['amount3'];}
       
        $address_status= $_REQUEST['address_status'];
        $subscribed_date= $start_date;
        $payer_id= $_REQUEST['payer_id'];
        $address_street= $_REQUEST['address_street'];
        if($_REQUEST['mc_amount3']!=''){ $mc_amount3= $_REQUEST['mc_amount3']; }
        else { $mc_amount3= $_REQUEST['mc_fee']; }
            $charset= $_REQUEST['charset'];
        $address_zip= $_REQUEST['address_zip'];
        $first_name= $_REQUEST['first_name'];
        $reattempt= $_REQUEST['reattempt'];
        $address_country_code= $_REQUEST['address_country_code'];
        $address_name= $_REQUEST['address_name'];
        $notify_version= $_REQUEST['notify_version'];
        $subscr_id= $_REQUEST['subscr_id'];
        $payer_status= $_REQUEST['payer_status'];
        $business= $_REQUEST['business'];
        $address_country= $_REQUEST['address_country'];
        $address_city= $_REQUEST['address_city'];
        $payer_email= $_REQUEST['payer_email'];
        $btn_id= $_REQUEST['btn_id'];
        $last_name= $_REQUEST['last_name'];
        $address_state= $_REQUEST['address_state'];
        $receiver_email= $_REQUEST['receiver_email'];
        $recurring= $_REQUEST['recurring'];
        $txn_type= $_REQUEST['txn_type'];
        $item_name= $_REQUEST['item_name'];
        $mc_currency= $_REQUEST['mc_currency'];
        $item_number= $_REQUEST['item_number'];
        $residence_country= $_REQUEST['residence_country'];
        $test_ipn= $_REQUEST['test_ipn'];
        $period3= $_REQUEST['period3'];
        $ipn_track_id= $_REQUEST['ipn_track_id'];
        $user_id = $_REQUEST['custom'];
        $payment_status=$_REQUEST['payment_status'];
        if(($_REQUEST['payment_date'])!='')
        {
            $payment_date1 = trim(str_replace('PDT','',$_REQUEST['payment_date']));
            $payment_date1 = date('Y-m-d H:i:s',strtotime($payment_date1));					
            $start_date1 = date('Y-m-d',strtotime($payment_date1));
            $payment_date1=$start_date1;
        }


       // $result=$wpdb->query("INSERT INTO wp_payment_meta (amount, address_status,subscribed_date,payer_id,address_street,mc_amount3,charset,zip_code,first_name,payer_status,reattempt,country_code,address_name,notify_version,subscriber_id,business,address_country,address_city,verify_sign,payer_email,btn_id,last_name,address_state,receiver_email,recurring,txn_type,item_name,mc_currency,item_number,residence_country,test_ipn,period3,ipn_track_id) VALUES ('amount3','address_status','subscribed_date','payer_id','address_street','mc_amount3','harset',234,'first_name','payer_status',567,'address_country_code','address_name','notify_version','subscr_id','business','address_country','address_city','verify_sign','payer_email','btn_id','last_name','address_state','receiver_email','recurring','txn_type','item_name','mc_currency','item_number','residence_country','test_ipn','period3','wrt')");
        $result=$wpdb->query("INSERT INTO wp_payment_meta (amount, address_status,subscribed_date,payer_id,address_street,mc_amount3,charset,zip_code,first_name,payer_status,reattempt,country_code,address_name,notify_version,subscriber_id,business,address_country,address_city,verify_sign,payer_email,btn_id,last_name,address_state,receiver_email,recurring,txn_type,item_name,mc_currency,item_number,residence_country,test_ipn,period3,ipn_track_id,user_id,payment_status,payment_date) VALUES ('$amount3','$address_status','$subscribed_date','$payer_id','$address_street','$mc_amount3','$charset','$address_zip','$first_name','$payer_status','$reattempt','$address_country_code','$address_name','$notify_version','$subscr_id','$business','$address_country','$address_city','$verify_sign','$payer_email','$btn_id','$last_name','$address_state','$receiver_email','$recurring','$txn_type','$item_name','$mc_currency','$item_number','$residence_country','$test_ipn','$period3','$ipn_track_id','$user_id','$payment_status','$payment_date1')");
       mail('vigneswaran.askan@gmail.com','payapal IPN Responsed inserequery',print_r($_REQUEST,true));
       if(($result==true) && ($_REQUEST['payment_status'] == 'Completed'))
       {

        $wpdb->query($wpdb->prepare("UPDATE wp_users  SET user_status=0 WHERE ID=$user_id"));
$u = new WP_User( $user_id );
$u->remove_role( 'student' );
$u->add_role( 'commercial' );
       }     

      //   }
//}
?>