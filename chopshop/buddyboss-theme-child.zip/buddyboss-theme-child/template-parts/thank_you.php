<?php
/* Template Name: Thank you */
get_header(); ?>

<div class="jumbotron text-center" style="margin-top:10%">
  <h1 class="display-3">Thank You for signing up!</h1>
 
  <hr>
  <p>
    Enjoy our <a href="https://chopshopfx.com/speed/search-sound-effects/">sound effects</a>
  </p>
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="https://chopshopfx.com/speed/my-account/" role="button">Continue to homepage</a>
  </p>
</div>

<?php get_footer();