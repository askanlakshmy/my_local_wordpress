<?php
/* Template Name: Import User */
get_header();
?>
<div class="container" style='margin-top:40px;text-align:center;'>
<div class="row">
      <div class="col-md-6" >
          <div class="import_form">
              <form method="post" enctype="multipart/form-data" id="importuser">
                  <input type='file' name='file_upload_user' id='file_upload_user' accept=".csv">
                  <input type="submit" name="submit_user" value="Submit" id="submit_user">
              </form>
          </div>
      </div>
</div>
<div class="col-md-6" >
<?php


function generateRandomString($length = 8)
{
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
if (isset($_POST['submit_user'])) {
    // $filename=$_POST['file_upload_user'];
    $filename = basename($_FILES["file_upload_user"]["name"]);
    $imageFileType = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    //echo $imageFileType;
    if ($imageFileType == 'csv') {
        //exit;
        // die;
        global $wpdb;
        $a = 1;
        $fi_arr = [];
        $vv=0;
        $file = fopen($_FILES['file_upload_user']['tmp_name'], 'r');
        while (($line = fgetcsv($file)) !== false) {
             if($vv>=1)
             {
             // echo $line;
                $fi_arr[] = $line;
           }
     $vv++;
          
        }
        //print_r($fi_arr);
      ///  die;
        ?>
<table class='table-styles' style="border:1px solid black;">
<tr><th>&nbsp;&nbsp;Sl.No</th><th>&nbsp;&nbsp;Status</th><th>&nbsp;&nbsp;Email</th><th>&nbsp;&nbsp;Mail Status</th></tr>
<?php
foreach ($fi_arr as $key => $vauser) {
            // $entries = [];
            // echo "<pre>";
            // print_r($vauser);
            // echo "</pre>";
            $date = date("Y/m/d");
            $st = $vauser['3'] . ' months';
            $date = date_create($date);
            date_add($date, date_interval_create_from_date_string($st));
            $course_durations = date_format($date, 'Y/m/d');

            $fullname = $vauser['1'] . $vauser['0'];
            if (null == email_exists($vauser['2'])) {

                // Generate the password and create the user
                $password = wp_generate_password(12, false);
                $user_id = wp_create_user($fullname, $password, $fullname);
                //print_r($user_id);
                //exit;
                // Set the nickname
                wp_update_user(
                    array(
                        'ID' => $user_id,
                        'nickname' => $fullname,
                    )
                );
                // Set the role
                $user = new WP_User($user_id);
                $user->set_role('student');
                $get_meta = array('degree_length' => $vauser['3'], 'School' => $vauser['4'], 'degree' => $vauser['5'], 'notes' => $vauser['6'], 'course_duration' => $course_durations);

                foreach ($get_meta as $meta_key => $meta_value) {
                    add_user_meta($user_id, $meta_key, $meta_value, $unique = false);
                }
                $user_data = wp_update_user(array('ID' => $user_id, 'user_email' => $vauser['2'], 'display_name' => $vauser['1']));
                update_user_meta($user_id,'first_name',$vauser['1']);
                update_user_meta($user_id,'last_name',$vauser['0']);
               // print_r($user_data);
                                ?>
               <?php

                if (is_wp_error($user_id)) {
                    echo "<tr><td> " ."&nbsp;&nbsp;&nbsp;".$a . "</td><td style='color:red;'>This user already Exists!</td><td>" . $vauser['2'] . "</td><td style='color:red;>Existing User!</td></tr>";
                    echo "<br>";
                    $a++;
                } else {
                    
                    $to = $vauser['2'];
                    $subject = 'Welcome to Chop Shop FX';
                    $siteurl=site_url().'/my-account/';
                    //echo $siteurl;
                    $newpass = "Dear " . $vauser['1'].',' . "<br/><br/>
Your account has been registered at Chop Shop FX. You can <a href=".$siteurl.">access your account</a> with this password <b>" . $password . "</b><br/><br/>
Here is a link for a collection of 5,000 sound effects from Chop Shop FX to use during your program.   Just <a href='https://chopshopfx.com/speed/my-account/downloads-sfx/'>click this link</a> to download the collection and read the included Student License Agreement for Terms Of Use.<br/><br/>
Make some noise!<br>
Chop Shop FX Team<br>";
//$attachments = array( WP_CONTENT_DIR . '/uploads/test.zip' );
                    $headers = 'From: Chop Shop FX <help@chopshopfx.com>' . "\r\n";
// // wp_mail( $to, $subject, $message, $headers, $attachments );
                    $success_mail=wp_mail($to, $subject, $newpass, $headers);
                    if($success_mail==true)
                    {
                        $mailstatus="<span style='color:green;'>Mail Sent!</span>";
                    }
                    else
                    {
                        $mailstatus="<span style='color:red;'>Mail not Sent!</span>";
                    }
                    echo "<tr><td>" . "&nbsp;&nbsp;&nbsp;".$a . "</td><td style='color:green;'>This user Added</td><td>" . $vauser['2'] . "</td><td>".$mailstatus."</td></tr>";
                    echo "<br>";
                    $a++;

                    $couponcode = generateRandomString();
                  //  if ($user_id != $exits_user || $exits_user == '') {

                        $wpdb->insert('wp_copons_meta', array(
                            'user_id' => $user_id,
                            'coupons_code' => $couponcode,
                        ));
                  //  }
                    
                }

            }
            else
            {
                // if (is_wp_error($user_data)) {
                    echo "<tr><td>" ."&nbsp;&nbsp;&nbsp;" .$a . "</td><td style='color:red;'>This user already Exists!</td><td>" . $vauser['2'] . "</td><td style='color:red;'>Existing User!</td></tr>";
                  //  echo "<br>";
                    $a++;
                }
            }
        }

 else {
        echo "<p style='color:red; text-align:center;'>Please upload only CSV files!</p>";
    }
    ?>
    </table>
<?php }

?>
</div>
</div>
 <?php get_footer();?>